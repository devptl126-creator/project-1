<?php
require_once '../config.php';
requireRole('admin');

$active_garages   = $conn->query("SELECT COUNT(*) as c FROM garages WHERE is_approved = 1")->fetch_assoc()['c'];
$pending_requests = $conn->query("SELECT COUNT(*) as c FROM service_requests WHERE status = 'pending'")->fetch_assoc()['c'];
$users_count      = $conn->query("SELECT COUNT(*) as c FROM users")->fetch_assoc()['c'];
$drivers_count    = $conn->query("SELECT COUNT(*) as c FROM users WHERE role='driver'")->fetch_assoc()['c'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard – RoadRescue</title>
  <link rel="stylesheet" href="/roadside_ally_php/assets/css/style.css">
  <style>
    .admin-stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
      gap: 1.5rem;
      margin-bottom: 2rem;
    }

    /* Modernized UIverse Card */
    .uiverse-card {
      width: 100%;
      height: 190px;
      background: linear-gradient(145deg, #ffffff, #f8fafc);
      border: 1px solid var(--border);
      border-radius: var(--radius);
      padding: 1.25rem;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
      transition: transform 0.2s ease, box-shadow 0.2s ease, border-color 0.2s ease;
    }
    
    .uiverse-card:hover {
      transform: translateY(-4px);
      box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.08);
      border-color: var(--primary);
    }

    .tools {
      display: flex;
      align-items: center;
      padding: 0.25rem 0;
    }

    .circle {
      padding: 0 4px;
    }

    .box {
      display: inline-block;
      align-items: center;
      width: 10px;
      height: 10px;
      padding: 1px;
      border-radius: 50%;
    }

    .red { background-color: #ef4444; }
    .yellow { background-color: #f59e0b; }
    .green { background-color: #22c55e; }

    .card__content {
      display: flex;
      flex-direction: column;
      justify-content: center;
      margin-top: 0.5rem;
    }

    .stat-label {
      font-size: 0.825rem;
      color: var(--muted-fg);
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      margin-bottom: 0.35rem;
    }

    .stat-value {
      font-size: 2.1rem;
      font-weight: 800;
      color: #0f172a;
    }

    .admin-actions {
      display: flex;
      gap: 1rem;
      margin-top: 1rem;
      flex-wrap: wrap;
    }
    
    .recent-activity {
      margin-top: 2rem;
      background: #fff;
      border: 1px solid var(--border);
      border-radius: var(--radius);
      padding: 1.5rem;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
    }
  </style>
</head>
<body>
<?php include '../includes/sidebar.php'; ?>

<div class="main-content">
  <header class="topbar">
    <button class="sidebar-toggle" onclick="toggleSidebar()">&#9776;</button>
    <h2>Admin Panel</h2>
  </header>
  
  <main class="page-body">
    <h1 class="page-title">Admin Dashboard</h1>

    <div class="admin-stats-grid">
      
      <a href="/roadside_ally_php/admin/garages.php" style="text-decoration: none; color: inherit;">
        <div class="uiverse-card">
          <div class="tools">
            <div class="circle"><span class="red box"></span></div>
            <div class="circle"><span class="yellow box"></span></div>
            <div class="circle"><span class="green box"></span></div>
          </div>
          <div class="card__content">
            <p class="stat-label">Active Garages</p>
            <p class="stat-value"><?= $active_garages ?></p>
          </div>
        </div>
      </a>

      <a href="/roadside_ally_php/admin/requests.php" style="text-decoration: none; color: inherit;">
        <div class="uiverse-card">
          <div class="tools">
            <div class="circle"><span class="red box"></span></div>
            <div class="circle"><span class="yellow box"></span></div>
            <div class="circle"><span class="green box"></span></div>
          </div>
          <div class="card__content">
            <p class="stat-label">Pending Requests</p>
            <p class="stat-value"><?= $pending_requests ?></p>
          </div>
        </div>
      </a>

      <a href="/roadside_ally_php/admin/users.php" style="text-decoration: none; color: inherit;">
        <div class="uiverse-card">
          <div class="tools">
            <div class="circle"><span class="red box"></span></div>
            <div class="circle"><span class="yellow box"></span></div>
            <div class="circle"><span class="green box"></span></div>
          </div>
          <div class="card__content">
            <p class="stat-label">Total Users</p>
            <p class="stat-value"><?= $users_count ?></p>
          </div>
        </div>
      </a>

      <a href="/roadside_ally_php/admin/users.php?role=driver" style="text-decoration: none; color: inherit;">
        <div class="uiverse-card">
          <div class="tools">
            <div class="circle"><span class="red box"></span></div>
            <div class="circle"><span class="yellow box"></span></div>
            <div class="circle"><span class="green box"></span></div>
          </div>
          <div class="card__content">
            <p class="stat-label">Total Drivers</p>
            <p class="stat-value"><?= $drivers_count ?></p>
          </div>
        </div>
      </a>
    </div>

    <div class="recent-activity">
      <div style="margin-bottom:1.25rem;">
        <strong style="font-size:1.15rem; color:#0f172a">Quick Navigation</strong>
        <p style="font-size:0.85rem; color:var(--muted-fg)">Jump to specific management modules</p>
      </div>
      <div class="admin-actions">
        <a href="/roadside_ally_php/admin/garages.php" class="btn btn-primary" style="background-color: var(--primary);">Manage Garages</a>
        <a href="/roadside_ally_php/admin/users.php" class="btn btn-primary" style="background-color: #475569;">Manage Users</a>
        <a href="/roadside_ally_php/admin/requests.php" class="btn btn-primary" style="background-color: #0891b2;">All Requests</a>
        <a href="/roadside_ally_php/admin/settings.php" class="btn btn-primary" style="background-color: #64748b;">Settings</a>
      </div>
    </div>
  </main>
</div>

<script src="/roadside_ally_php/assets/js/main.js"></script>
</body>
</html>