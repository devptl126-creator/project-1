<?php
require_once '../config.php';
requireRole('admin');

// Handle approve/disapprove/revoke
if (isset($_GET['action'], $_GET['id'])) {
    $id = (int)$_GET['id'];
    if ($_GET['action'] === 'approve')     $conn->query("UPDATE garages SET is_approved=1 WHERE id=$id");
    if ($_GET['action'] === 'disapprove')  $conn->query("UPDATE garages SET is_approved=2 WHERE id=$id");
    if ($_GET['action'] === 'revoke')      $conn->query("UPDATE garages SET is_approved=2 WHERE id=$id");
    redirect('/roadside_ally_php/admin/garages.php');
}

// Handle lat/lng update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_coords'])) {
    $id  = (int)$_POST['garage_id'];
    $lat = (float)$_POST['latitude'];
    $lng = (float)$_POST['longitude'];
    $stmt = $conn->prepare("UPDATE garages SET latitude=?, longitude=? WHERE id=?");
    $stmt->bind_param("ddi", $lat, $lng, $id);
    $stmt->execute();
    $coord_msg = "Coordinates saved for garage #$id";
    redirect('/roadside_ally_php/admin/garages.php?msg=saved');
}

$coord_msg = isset($_GET['msg']) ? '✅ Coordinates saved.' : '';

$garages     = $conn->query("SELECT * FROM garages ORDER BY created_at DESC")->fetch_all(MYSQLI_ASSOC);
$approved    = array_filter($garages, fn($g) => $g['is_approved'] == 1);
$disapproved = array_filter($garages, fn($g) => $g['is_approved'] == 2);
$pending     = array_filter($garages, fn($g) => !in_array($g['is_approved'], [1,2]));
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manage Garages – RoadRescue</title>
  <link rel="stylesheet" href="/roadside_ally_php/assets/css/style.css">
  <style>
    .management-container { display:flex;flex-direction:column;gap:1.5rem;margin-top:1.5rem; }
    .division-card { background:var(--card-bg);border:1px solid var(--border);border-radius:var(--radius);padding:1.5rem;box-shadow:0 4px 6px -1px rgba(44,104,123,.05); }
    .division-header { padding-bottom:1rem;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center;margin-bottom:1.25rem; }
    .division-header h3 { font-size:1.25rem;font-weight:800;color:var(--secondary); }
    .counter-badge { font-size:.75rem;font-weight:700;padding:.35rem .75rem;border-radius:999px; }
    .table-responsive { width:100%;overflow-x:auto; }
    .styled-table { width:100%;border-collapse:collapse;text-align:left;font-size:.875rem; }
    .styled-table th { background:var(--muted);padding:.85rem 1rem;font-weight:700;color:var(--secondary);border-bottom:1.5px solid var(--border); }
    .styled-table td { padding:.9rem 1rem;border-bottom:1px solid var(--border);color:var(--text);word-wrap:break-word; }
    .styled-table tr:last-child td { border-bottom:none; }
    .styled-table tr:hover td { background:var(--muted); }
    .action-group { display:flex;gap:.5rem;flex-wrap:wrap; }
    .btn-table-action { font-size:.75rem;font-weight:600;padding:.35rem .75rem;border-radius:var(--radius);text-decoration:none;border:none;cursor:pointer;display:inline-block; }
    .btn-approve    { background:var(--secondary);color:#fff; }
    .btn-disapprove { background:var(--primary);color:#fff; }
    .btn-approve:hover    { opacity:.9; }
    .btn-disapprove:hover { background:var(--primary-hover); }
    .coords-form { display:flex;gap:.4rem;align-items:center;margin-top:.5rem;flex-wrap:wrap; }
    .coords-form input { width:100px;padding:.28rem .5rem;border:1px solid var(--border);border-radius:var(--radius);font-size:.75rem; }
    .btn-coords { font-size:.72rem;font-weight:600;padding:.28rem .65rem;border-radius:var(--radius);background:#6366f1;color:#fff;border:none;cursor:pointer; }
    .has-coords { color:#10b981;font-size:.72rem;font-weight:600; }
    .no-coords  { color:#ef4444;font-size:.72rem; }
  </style>
</head>
<body>
<?php include '../includes/sidebar.php'; ?>
<div class="main-content">
  <header class="topbar">
    <button class="sidebar-toggle" onclick="toggleSidebar()">☰</button>
    <h2>Admin Panel</h2>
  </header>
  <main class="page-body">
    <h1 class="page-title">Manage Garages</h1>
    <?php if ($coord_msg): ?><div class="alert alert-success"><?= $coord_msg ?></div><?php endif; ?>

    <div class="management-container">

      <?php
      $sections = [
        ['title'=>'Approved Garages',    'badge'=>'badge-approved', 'data'=>$approved,    'actions'=>['revoke']],
        ['title'=>'Pending Requests',    'badge'=>'badge-pending',  'data'=>$pending,     'actions'=>['approve','disapprove']],
        ['title'=>'Disapproved Garages', 'badge'=>'badge-danger',   'data'=>$disapproved, 'actions'=>['approve']],
      ];
      foreach ($sections as $sec): ?>
      <div class="division-card">
        <div class="division-header">
          <h3><?= $sec['title'] ?></h3>
          <span class="counter-badge <?= $sec['badge'] ?>"><?= count($sec['data']) ?></span>
        </div>
        <div class="table-responsive">
          <table class="styled-table">
            <thead>
              <tr>
                <th style="width:22%">Garage Name</th>
                <th style="width:15%">Phone</th>
                <th style="width:25%">Address</th>
                <th style="width:22%">GPS Coordinates</th>
                <th style="width:16%">Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($sec['data'] as $g): ?>
              <tr>
                <td><strong><?= htmlspecialchars($g['name']) ?></strong></td>
                <td><?= htmlspecialchars($g['phone'] ?? 'N/A') ?></td>
                <td>📍 <?= htmlspecialchars(($g['address']??'').', '.($g['city']??'')) ?></td>
                <td>
                  <?php if (!empty($g['latitude']) && !empty($g['longitude'])): ?>
                    <span class="has-coords">✔ <?= round($g['latitude'],4) ?>, <?= round($g['longitude'],4) ?></span>
                  <?php else: ?>
                    <span class="no-coords">✘ No GPS</span>
                  <?php endif; ?>
                  <!-- Edit coords inline -->
                  <form method="POST" class="coords-form">
                    <input type="hidden" name="garage_id" value="<?= $g['id'] ?>">
                    <input type="number" step="any" name="latitude"  placeholder="Lat"  value="<?= $g['latitude']??'' ?>">
                    <input type="number" step="any" name="longitude" placeholder="Lng"  value="<?= $g['longitude']??'' ?>">
                    <button type="submit" name="save_coords" class="btn-coords">💾 Save</button>
                  </form>
                </td>
                <td>
                  <div class="action-group">
                    <?php if (in_array('approve', $sec['actions'])): ?>
                      <a href="?action=approve&id=<?= $g['id'] ?>" class="btn-table-action btn-approve">Approve</a>
                    <?php endif; ?>
                    <?php if (in_array('disapprove', $sec['actions'])): ?>
                      <a href="?action=disapprove&id=<?= $g['id'] ?>" class="btn-table-action btn-disapprove">Disapprove</a>
                    <?php endif; ?>
                    <?php if (in_array('revoke', $sec['actions'])): ?>
                      <a href="?action=revoke&id=<?= $g['id'] ?>" class="btn-table-action btn-disapprove">Revoke</a>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
              <?php endforeach; ?>
              <?php if (empty($sec['data'])): ?>
                <tr><td colspan="5" class="text-center" style="color:var(--text-muted)">None found.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
      <?php endforeach; ?>

    </div>
  </main>
</div>
<script src="/roadside_ally_php/assets/js/main.js"></script>
</body>
</html>