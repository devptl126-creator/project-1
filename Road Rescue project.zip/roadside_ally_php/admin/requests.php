<?php
require_once '../config.php';
requireRole('admin');

$requests = $conn->query("
    SELECT sr.*, p.full_name as driver_name, g.name as garage_name
    FROM service_requests sr
    JOIN profiles p ON p.user_id = sr.driver_id
    JOIN garages g ON g.id = sr.garage_id
    ORDER BY sr.created_at DESC
")->fetch_all(MYSQLI_ASSOC);

$status_colors = [
    'pending' => 'badge-pending', 'accepted' => 'badge-blue',
    'mechanic_assigned' => 'badge-blue', 'in_progress' => 'badge-yellow',
    'completed' => 'badge-approved', 'cancelled' => 'badge-danger'
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>All Requests – RoadRescue</title>
  <link rel="stylesheet" href="/roadside_ally_php/assets/css/style.css">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>
<div class="main-content">
  <header class="topbar">
    <button class="sidebar-toggle" onclick="toggleSidebar()">&#9776;</button>
    <h2>Admin Panel</h2>
  </header>
  <main class="page-body">
    <h1 class="page-title">All Requests</h1>
    <div class="table-card">
      <table class="table">
        <thead><tr><th>Driver</th><th>Garage</th><th>Service</th><th>Location</th><th>Price</th><th>Date</th><th>Status</th></tr></thead>
        <tbody>
          <?php foreach ($requests as $r): ?>
          <tr>
            <td><?= htmlspecialchars($r['driver_name']) ?></td>
            <td><?= htmlspecialchars($r['garage_name']) ?></td>
            <td><?= ucfirst(str_replace('_',' ',$r['service_type'])) ?></td>
            <td><?= htmlspecialchars($r['location']) ?></td>
            <td>₹<?= number_format($r['price'], 2) ?></td>
            <td><?= date('M d, Y', strtotime($r['created_at'])) ?></td>
            <td><span class="badge <?= $status_colors[$r['status']] ?? '' ?>"><?= ucfirst(str_replace('_',' ',$r['status'])) ?></span></td>
          </tr>
          <?php endforeach; ?>
          <?php if (empty($requests)): ?>
          <tr><td colspan="7" class="text-center text-muted">No requests yet.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </main>
</div>
<script src="/roadside_ally_php/assets/js/main.js"></script>
</body>
</html>