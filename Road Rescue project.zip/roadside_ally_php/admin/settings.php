<?php
require_once '../config.php';
requireRole('admin');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Settings – RoadRescue</title>
  <link rel="stylesheet" href="/roadside_ally_php/assets/css/style.css">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>
<div class="main-content">
  <header class="topbar">
    <button class="sidebar-toggle" onclick="toggleSidebar()">&#9776;</button>
    <h2>Admin Panel</h2>
  </header>
  <main class="page-body">
    <h1 class="page-title">Settings</h1>
    <div class="card">
      <div class="card-header" style="text-align:left"><strong>System Configuration</strong></div>
      <div class="card-body">
        <p class="text-muted">No settings are configured at this time.</p>
      </div>
    </div>
  </main>
</div>
<script src="/roadside_ally_php/assets/js/main.js"></script>
</body>
</html>