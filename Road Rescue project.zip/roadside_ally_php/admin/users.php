<?php
require_once '../config.php';
requireRole('admin');

$filter = $_GET['role'] ?? 'all';

if ($filter === 'all') {
    $result = $conn->query("SELECT p.full_name, p.phone, u.role, u.created_at FROM profiles p JOIN users u ON u.id = p.user_id ORDER BY u.created_at DESC");
} else {
    $stmt = $conn->prepare("SELECT p.full_name, p.phone, u.role, u.created_at FROM profiles p JOIN users u ON u.id = p.user_id WHERE u.role = ? ORDER BY u.created_at DESC");
    $stmt->bind_param("s", $filter);
    $stmt->execute();
    $result = $stmt->get_result();
}
$users = $result->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manage Users – RoadRescue</title>
  <link rel="stylesheet" href="/roadside_ally_php/assets/css/style.css">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>
<div class="main-content">
  <header class="topbar">
    <button class="sidebar-toggle" onclick="toggleSidebar()">&#9776;</button>
    <h2>Admin Panel</h2>
  </header>
  <main class="page-body">
    <div class="page-header">
      <h1 class="page-title">Manage Users</h1>
      <select class="filter-select" onchange="location='?role='+this.value">
        <option value="all" <?= $filter==='all'?'selected':'' ?>>All Roles</option>
        <option value="driver" <?= $filter==='driver'?'selected':'' ?>>Drivers</option>
        <option value="garage_owner" <?= $filter==='garage_owner'?'selected':'' ?>>Garage Owners</option>
        <option value="mechanic" <?= $filter==='mechanic'?'selected':'' ?>>Mechanics</option>
        <option value="admin" <?= $filter==='admin'?'selected':'' ?>>Admins</option>
      </select>
    </div>
    <div class="table-card">
      <table class="table">
        <thead><tr><th>Name</th><th>Phone</th><th>Role</th><th>Joined</th></tr></thead>
        <tbody>
          <?php foreach ($users as $u): ?>
          <tr>
            <td><strong><?= htmlspecialchars($u['full_name']) ?></strong></td>
            <td><?= $u['phone'] ?: '—' ?></td>
            <td><span class="badge badge-<?= $u['role'] ?>"><?= ucfirst(str_replace('_',' ',$u['role'])) ?></span></td>
            <td><?= date('M d, Y', strtotime($u['created_at'])) ?></td>
          </tr>
          <?php endforeach; ?>
          <?php if (empty($users)): ?>
          <tr><td colspan="4" class="text-center text-muted">No users found.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </main>
</div>
<script src="/roadside_ally_php/assets/js/main.js"></script>
</body>
</html>