// ── Sidebar toggle — desktop collapses width, mobile slides in/out ──────────
function toggleSidebar() {
  var sidebar  = document.getElementById('sidebar');
  var overlay  = document.getElementById('sidebar-overlay');
  var isMobile = window.innerWidth <= 768;

  if (isMobile) {
    sidebar.classList.toggle('mobile-open');
    if (overlay) overlay.classList.toggle('active');
  } else {
    sidebar.classList.toggle('collapsed');
  }
}

// Close sidebar when overlay is tapped on mobile
document.addEventListener('DOMContentLoaded', function () {
  var overlay = document.getElementById('sidebar-overlay');
  if (overlay) {
    overlay.addEventListener('click', function () {
      document.getElementById('sidebar').classList.remove('mobile-open');
      overlay.classList.remove('active');
    });
  }

  // Close sidebar on mobile when a nav link is tapped
  if (window.innerWidth <= 768) {
    document.querySelectorAll('.sidebar-link').forEach(function (link) {
      link.addEventListener('click', function () {
        var sidebar = document.getElementById('sidebar');
        var overlay = document.getElementById('sidebar-overlay');
        // Only close if it's a real link (not a dropdown toggle)
        if (this.getAttribute('href') && this.getAttribute('href') !== 'javascript:void(0)') {
          sidebar.classList.remove('mobile-open');
          if (overlay) overlay.classList.remove('active');
        }
      });
    });
  }

  // Dropdown toggle (tap-friendly for mobile)
  document.querySelectorAll('.sidebar-dropdown-container > .sidebar-link').forEach(function (trigger) {
    trigger.addEventListener('click', function (e) {
      if (window.innerWidth <= 768) {
        e.preventDefault();
        var menu = this.nextElementSibling;
        if (menu) menu.classList.toggle('open');
      }
    });
  });
});

// Legacy dropdown toggle (kept for backward compat)
function toggleDropdown(id) {
  var dropdown = document.getElementById(id);
  if (dropdown) {
    dropdown.classList.toggle('show');
  }
}