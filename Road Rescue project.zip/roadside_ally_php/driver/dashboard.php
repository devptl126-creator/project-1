<?php
require_once '../config.php';
requireRole('driver');

$uid  = $_SESSION['user_id'];
$name = $_SESSION['full_name'] ?? 'Driver';

// Get all requests for this driver
$requests = $conn->query(
    "SELECT sr.*, g.name AS garage_name
     FROM service_requests sr
     LEFT JOIN garages g ON sr.garage_id = g.id
     WHERE sr.driver_id = $uid
     ORDER BY sr.created_at DESC"
)->fetch_all(MYSQLI_ASSOC);

// ✅ PHP 7.3 compatible — no fn() arrow function
$active    = array_filter($requests, function($r) { return !in_array($r['status'], ['completed','cancelled']); });
$completed = array_filter($requests, function($r) { return $r['status'] === 'completed'; });

$status_colors = [
    'pending'           => 'badge-pending',
    'accepted'          => 'badge-blue',
    'mechanic_assigned' => 'badge-blue',
    'in_progress'       => 'badge-yellow',
    'completed'         => 'badge-approved',
    'cancelled'         => 'badge-danger',
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Driver Dashboard – RoadRescue</title>
  <link rel="stylesheet" href="/roadside_ally_php/assets/css/driver.css">
  <style>
    .welcome-banner {
      background: linear-gradient(135deg, var(--primary), var(--primary-hover));
      color: #fff;
      border-radius: var(--radius);
      padding: 1.5rem 1.75rem;
      margin-bottom: 1.75rem;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 1rem;
      flex-wrap: wrap;
    }
    .welcome-banner h2 { font-size: 1.3rem; font-weight: 800; margin-bottom: 0.2rem; }
    .welcome-banner p  { font-size: 0.875rem; opacity: 0.85; }
    .welcome-banner .btn-light {
      background: rgba(255,255,255,0.2);
      color: #fff;
      border: 1.5px solid rgba(255,255,255,0.4);
      padding: 0.55rem 1.25rem;
      border-radius: var(--radius);
      font-weight: 700;
      font-size: 0.875rem;
      text-decoration: none;
      transition: background .2s;
      white-space: nowrap;
    }
    .welcome-banner .btn-light:hover { background: rgba(255,255,255,0.35); }

    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
      gap: 1.1rem;
      margin-bottom: 1.75rem;
    }
    .stat-card { transition: transform .2s; }
    .stat-card:hover { transform: translateY(-3px); }

    .section-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 1rem;
    }
    .section-header h3 { font-size: 1rem; font-weight: 800; color: var(--secondary); }

    .request-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 1rem;
      padding: 1rem 1.25rem;
      border-bottom: 1px solid var(--border);
      transition: background .15s;
    }
    .request-row:last-child { border-bottom: none; }
    .request-row:hover { background: var(--muted); }
    .request-row .r-type {
      font-weight: 700;
      font-size: 0.925rem;
      color: var(--secondary);
      text-transform: capitalize;
    }
    .request-row .r-meta {
      font-size: 0.8rem;
      color: var(--text-muted);
      margin-top: 0.2rem;
    }
    .request-row .r-right { text-align: right; flex-shrink: 0; }
    .request-row .r-price {
      font-weight: 700;
      color: var(--primary);
      font-size: 0.95rem;
    }
    .request-row .r-date {
      font-size: 0.75rem;
      color: var(--text-muted);
      margin-top: 0.2rem;
    }

    .empty-state {
      text-align: center;
      padding: 2.5rem 1rem;
      color: var(--text-muted);
    }
    .empty-state .empty-icon { font-size: 2.5rem; margin-bottom: 0.75rem; }
    .empty-state p { font-size: 0.9rem; margin-bottom: 1.25rem; }
  </style>
</head>
<body>

<?php include '../includes/sidebar.php'; ?>

<div class="main-content">
  <header class="topbar">
    <button class="sidebar-toggle" onclick="toggleSidebar()">&#9776;</button>
    <h2>Driver Dashboard</h2>
  </header>

  <main class="page-body">

    <!-- Welcome Banner -->
    <div class="welcome-banner">
      <div>
        <h2>Welcome back, <?= htmlspecialchars($name) ?> 👋</h2>
        <p>Need roadside help? Request a service and we'll connect you with a nearby garage.</p>
      </div>
      <a href="/roadside_ally_php/driver/request.php" class="btn-light">+ New Request</a>
    </div>

    <!-- Stats -->
    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-icon icon-cyan">📋</div>
        <div>
          <p class="stat-label">Total Requests</p>
          <p class="stat-value"><?= count($requests) ?></p>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon icon-yellow">🔧</div>
        <div>
          <p class="stat-label">Active Jobs</p>
          <p class="stat-value"><?= count($active) ?></p>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon icon-green">✅</div>
        <div>
          <p class="stat-label">Completed</p>
          <p class="stat-value"><?= count($completed) ?></p>
        </div>
      </div>
    </div>

    <!-- Recent Requests -->
    <div class="card" style="margin-bottom:1.5rem">
      <div class="card-header" style="padding:1.1rem 1.25rem">
        <div class="section-header" style="margin-bottom:0">
          <h3>Recent Service Requests</h3>
          <a href="/roadside_ally_php/driver/history.php" class="btn btn-sm" style="background:var(--muted);color:var(--secondary)">View All</a>
        </div>
      </div>
      <div class="card-body" style="padding:0">
        <?php if (empty($requests)): ?>
          <div class="empty-state">
            <div class="empty-icon">🚗</div>
            <p>No service requests yet. Tap the button below to get started.</p>
            <a href="/roadside_ally_php/driver/request.php" class="btn btn-primary">Request a Service</a>
          </div>
        <?php else: ?>
          <?php foreach (array_slice($requests, 0, 6) as $r): ?>
            <div class="request-row">
              <div>
                <div class="r-type"><?= ucfirst(str_replace('_', ' ', $r['service_type'])) ?></div>
                <div class="r-meta">
                  🏪 <?= htmlspecialchars($r['garage_name'] ?? 'Unassigned') ?>
                  &nbsp;·&nbsp;
                  📍 <?= htmlspecialchars($r['location'] ?? '—') ?>
                </div>
              </div>
              <div class="r-right">
                <span class="badge <?= $status_colors[$r['status']] ?? 'badge-pending' ?>">
                  <?= ucfirst(str_replace('_', ' ', $r['status'])) ?>
                </span>
                <?php if ($r['price'] > 0): ?>
                  <div class="r-price">₹<?= number_format($r['price'], 2) ?></div>
                <?php endif; ?>
                <div class="r-date"><?= date('d M Y', strtotime($r['created_at'])) ?></div>
              </div>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>

  </main>
</div>

<script src="/roadside_ally_php/assets/js/main.js"></script>
</body>
</html>