<?php
require_once '../config.php';
requireRole('driver');
$uid = $_SESSION['user_id'];

$requests = $conn->query("
    SELECT sr.*, g.name as garage_name
    FROM service_requests sr
    JOIN garages g ON g.id = sr.garage_id
    WHERE sr.driver_id = $uid
    ORDER BY sr.created_at DESC
")->fetch_all(MYSQLI_ASSOC);

$status_colors = ['pending'=>'badge-pending','accepted'=>'badge-blue','mechanic_assigned'=>'badge-blue','in_progress'=>'badge-yellow','completed'=>'badge-approved','cancelled'=>'badge-danger'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Request History – RoadRescue</title>
  <link rel="stylesheet" href="/roadside_ally_php/assets/css/driver.css">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>
<div class="main-content">
  <header class="topbar">
    <button class="sidebar-toggle" onclick="toggleSidebar()">&#9776;</button>
    <h2>Driver Panel</h2>
  </header>
  <main class="page-body">
    <h1 class="page-title">Request History</h1>
    <div class="table-card">
      <table class="table">
        <thead><tr><th>Service</th><th>Garage</th><th>Location</th><th>Price</th><th>Date</th><th>Status</th></tr></thead>
        <tbody>
          <?php foreach ($requests as $r): ?>
          <tr>
            <td><?= ucfirst(str_replace('_',' ',$r['service_type'])) ?></td>
            <td><?= htmlspecialchars($r['garage_name']) ?></td>
            <td><?= htmlspecialchars($r['location']) ?></td>
            <td>₹<?= number_format($r['price'],2) ?></td>
            <td><?= date('M d, Y', strtotime($r['created_at'])) ?></td>
            <td><span class="badge <?= $status_colors[$r['status']] ?>"><?= ucfirst(str_replace('_',' ',$r['status'])) ?></span></td>
          </tr>
          <?php endforeach; ?>
          <?php if (empty($requests)): ?>
          <tr><td colspan="6" class="text-center text-muted">No requests yet.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </main>
</div>
<script src="/roadside_ally_php/assets/js/main.js"></script>
</body>
</html>