<?php
require_once '../config.php';
requireRole('driver');
$uid = $_SESSION['user_id'];

$profile = $conn->query("SELECT * FROM profiles WHERE user_id=$uid")->fetch_assoc();
$user    = $conn->query("SELECT email FROM users WHERE id=$uid")->fetch_assoc();
$vehicle = $conn->query("SELECT * FROM driver_vehicles WHERE user_id=$uid LIMIT 1")->fetch_assoc();

$success = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['save_profile'])) {
        $name = trim($_POST['full_name']);
        $phone = trim($_POST['phone']);
        $stmt = $conn->prepare("UPDATE profiles SET full_name=?, phone=? WHERE user_id=?");
        $stmt->bind_param("ssi", $name, $phone, $uid);
        $stmt->execute() ? $success = 'Profile updated.' : $error = 'Update failed.';
        $_SESSION['full_name'] = $name;
    }
    if (isset($_POST['save_vehicle'])) {
        $make  = trim($_POST['make']);
        $model = trim($_POST['model']);
        $year  = (int)$_POST['year'];
        $plate = trim($_POST['license_plate']);
        if ($vehicle) {
            $stmt = $conn->prepare("UPDATE driver_vehicles SET make=?,model=?,year=?,license_plate=? WHERE user_id=?");
            $stmt->bind_param("ssisi", $make, $model, $year, $plate, $uid);
        } else {
            $stmt = $conn->prepare("INSERT INTO driver_vehicles (user_id,make,model,year,license_plate) VALUES (?,?,?,?,?)");
            $stmt->bind_param("issis", $uid, $make, $model, $year, $plate);
        }
        $stmt->execute() ? $success = 'Vehicle updated.' : $error = 'Update failed.';
        $vehicle = $conn->query("SELECT * FROM driver_vehicles WHERE user_id=$uid LIMIT 1")->fetch_assoc();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My Profile – RoadRescue</title>
  <link rel="stylesheet" href="/roadside_ally_php/assets/css/driver.css">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>
<div class="main-content">
  <header class="topbar">
    <button class="sidebar-toggle" onclick="toggleSidebar()">&#9776;</button>
    <h2>Driver Panel</h2>
  </header>
  <main class="page-body">
    <h1 class="page-title">My Profile</h1>
    <?php if ($success): ?><div class="alert alert-success"><?= $success ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error"><?= $error ?></div><?php endif; ?>
    <div class="two-col-grid">
      <div class="card">
        <div class="card-header" style="text-align:left"><strong>Personal Information</strong></div>
        <div class="card-body">
          <form method="POST">
            <div class="form-group"><label>Full Name</label><input type="text" name="full_name" value="<?= htmlspecialchars($profile['full_name']) ?>" required></div>
            <div class="form-group"><label>Email</label><input type="email" value="<?= htmlspecialchars($user['email']) ?>" disabled></div>
            <div class="form-group"><label>Phone</label><input type="text" name="phone" value="<?= htmlspecialchars($profile['phone'] ?? '') ?>"></div>
            <button type="submit" name="save_profile" class="btn btn-primary">Save Changes</button>
          </form>
        </div>
      </div>
      <div class="card">
        <div class="card-header" style="text-align:left"><strong>Vehicle Details</strong></div>
        <div class="card-body">
          <form method="POST">
            <div class="form-group"><label>Make</label><input type="text" name="make" value="<?= htmlspecialchars($vehicle['make'] ?? '') ?>"></div>
            <div class="form-group"><label>Model</label><input type="text" name="model" value="<?= htmlspecialchars($vehicle['model'] ?? '') ?>"></div>
            <div class="form-group"><label>Year</label><input type="number" name="year" value="<?= $vehicle['year'] ?? '' ?>"></div>
            <div class="form-group"><label>License Plate</label><input type="text" name="license_plate" value="<?= htmlspecialchars($vehicle['license_plate'] ?? '') ?>"></div>
            <button type="submit" name="save_vehicle" class="btn btn-primary">Save Changes</button>
          </form>
        </div>
      </div>
    </div>
  </main>
</div>
<script src="/roadside_ally_php/assets/js/main.js"></script>
</body>
</html>