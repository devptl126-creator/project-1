<?php
require_once '../config.php';
requireRole('driver');

$message = '';
$error   = '';

// ── AJAX: return garages sorted by distance ────────────────────────────────────
if (isset($_GET['fetch_garages'])) {
    $type = $conn->real_escape_string($_GET['service_type']);
    $lat  = isset($_GET['lat']) ? (float)$_GET['lat'] : null;
    $lng  = isset($_GET['lng']) ? (float)$_GET['lng'] : null;

    if ($lat && $lng) {
        $result = $conn->query(
            "SELECT g.id, g.name, g.city, g.address, g.phone, g.rating,
                    gs.name AS service_name, gs.price, gs.estimated_time,
                    (6371 * ACOS(
                        COS(RADIANS($lat)) * COS(RADIANS(g.latitude)) *
                        COS(RADIANS(g.longitude) - RADIANS($lng)) +
                        SIN(RADIANS($lat)) * SIN(RADIANS(g.latitude))
                    )) AS distance_km
             FROM garages g
             JOIN garage_services gs ON gs.garage_id = g.id
             WHERE g.is_approved = 1
               AND gs.service_type = '$type'
               AND g.latitude IS NOT NULL AND g.longitude IS NOT NULL
             ORDER BY distance_km ASC"
        );
    } else {
        $result = $conn->query(
            "SELECT g.id, g.name, g.city, g.address, g.phone, g.rating,
                    gs.name AS service_name, gs.price, gs.estimated_time,
                    NULL AS distance_km
             FROM garages g
             JOIN garage_services gs ON gs.garage_id = g.id
             WHERE g.is_approved = 1
               AND gs.service_type = '$type'
             ORDER BY g.rating DESC"
        );
    }

    $rows = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    header('Content-Type: application/json');
    echo json_encode($rows);
    exit;
}

// ── POST: insert service request ──────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $driver_id    = $_SESSION['user_id'];
    $garage_id    = (int)$_POST['garage_id'];
    $service_type = trim($_POST['service_type']);
    $notes        = trim($_POST['notes']);
    $location     = trim($_POST['location']);
    $price        = (float)$_POST['price'];

    if ($garage_id && $service_type && $location) {
        $stmt = $conn->prepare(
            "INSERT INTO service_requests
               (driver_id, garage_id, service_type, location, notes, price, status)
             VALUES (?, ?, ?, ?, ?, ?, 'pending')"
        );
        if ($stmt) {
            $stmt->bind_param("iisssd", $driver_id, $garage_id, $service_type, $location, $notes, $price);
            if ($stmt->execute()) {
                $message = "✅ Request submitted! The garage will contact you shortly.";
            } else {
                $error = "DB error: " . $conn->error;
            }
            $stmt->close();
        } else {
            $error = "Prepare error: " . $conn->error;
        }
    } else {
        $error = "Please complete all steps before submitting.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Request Service – RoadRescue</title>
  <link rel="stylesheet" href="/roadside_ally_php/assets/css/driver.css">
  <style>
    .steps { display:flex; align-items:center; justify-content:center; margin-bottom:2rem; }
    .step  { display:flex; flex-direction:column; align-items:center; gap:.35rem; }
    .step-circle { width:36px;height:36px;border-radius:50%;background:var(--border);color:var(--text-muted);font-weight:700;font-size:.875rem;display:flex;align-items:center;justify-content:center;border:2px solid var(--border);transition:all .3s; }
    .step-label  { font-size:.7rem;font-weight:600;color:var(--text-muted);white-space:nowrap;transition:color .3s; }
    .step.active .step-circle { background:var(--primary);color:#fff;border-color:var(--primary); }
    .step.active .step-label  { color:var(--primary); }
    .step.done  .step-circle  { background:#10b981;color:#fff;border-color:#10b981; }
    .step.done  .step-label   { color:#10b981; }
    .step-line  { flex:1;height:2px;background:var(--border);margin:0 8px;margin-bottom:22px;min-width:40px;transition:background .3s; }
    .step-line.done { background:#10b981; }

    .panel { display:none; }
    .panel.active { display:block; }

    .service-grid { display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:.85rem;margin-top:.75rem; }
    .service-card { border:2px solid var(--border);border-radius:var(--radius);padding:1.1rem .75rem;text-align:center;cursor:pointer;background:var(--card-bg);transition:all .2s; }
    .service-card:hover    { border-color:var(--primary);background:var(--muted); }
    .service-card.selected { border-color:var(--primary);background:#d4eef0; }
    .service-card .icon    { font-size:2rem;margin-bottom:.4rem; }
    .service-card .label   { font-size:.8rem;font-weight:700;color:var(--secondary); }

    .garage-list { display:flex;flex-direction:column;gap:.75rem;margin-top:.75rem; }
    .garage-card { border:2px solid var(--border);border-radius:var(--radius);padding:1rem 1.1rem;cursor:pointer;background:var(--card-bg);display:flex;justify-content:space-between;align-items:flex-start;gap:1rem;transition:all .2s; }
    .garage-card:hover    { border-color:var(--primary); }
    .garage-card.selected { border-color:var(--primary);background:#d4eef0; }
    .garage-card .g-name  { font-weight:700;color:var(--secondary); }
    .garage-card .g-meta  { font-size:.78rem;color:var(--text-muted);margin-top:.2rem; }
    .garage-card .g-price { font-weight:800;color:var(--primary);font-size:1rem;white-space:nowrap; }
    .garage-card .g-time  { font-size:.75rem;color:var(--text-muted);text-align:right;margin-top:.2rem; }
    .garage-card .g-dist  { font-size:.72rem;color:#10b981;font-weight:600;margin-top:.2rem; }
    .stars { color:#f59e0b;font-size:.8rem;margin-top:.25rem; }

    .no-garages { text-align:center;padding:2rem;color:var(--text-muted);background:var(--muted);border-radius:var(--radius);border:1px dashed var(--border);font-size:.875rem; }
    .loading { text-align:center;padding:2rem;color:var(--text-muted); }

    .summary-box { background:var(--muted);border:1px solid var(--border);border-radius:var(--radius);padding:.9rem 1.1rem;margin-bottom:1.25rem;font-size:.875rem;color:var(--secondary);line-height:1.9; }

    .btn-back { background:none;border:1.5px solid var(--border);color:var(--secondary);padding:.55rem 1.1rem;border-radius:var(--radius);font-weight:600;font-size:.875rem;cursor:pointer;transition:all .2s; }
    .btn-back:hover { border-color:var(--primary);color:var(--primary); }

    .btn-location { background:none;border:1.5px solid var(--primary);color:var(--primary);padding:.5rem 1rem;border-radius:var(--radius);font-weight:600;font-size:.8rem;cursor:pointer;transition:all .2s;margin-bottom:.75rem;display:flex;align-items:center;gap:.4rem; }
    .btn-location:hover { background:var(--primary);color:#fff; }
    .btn-location:disabled { opacity:.5;cursor:not-allowed; }

    .location-status { font-size:.75rem;margin-bottom:.5rem; }
    .location-status.ok  { color:#10b981; }
    .location-status.err { color:#ef4444; }

    /* GPS detecting animation box */
    .gps-detecting { text-align:center;padding:2rem 1rem;background:var(--muted);border-radius:var(--radius);border:1px solid var(--border); }
    .gps-detecting .spinner { font-size:2.5rem;animation:spin 1.5s linear infinite;display:inline-block; }
    @keyframes spin { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }
    .gps-detecting p { margin:.75rem 0 0;font-size:.875rem;color:var(--text-muted); }
    .gps-success { text-align:center;padding:1.5rem 1rem;background:#d1fae5;border-radius:var(--radius);border:1px solid #6ee7b7; }
    .gps-success .check { font-size:2.5rem; }
    .gps-success p { margin:.5rem 0 0;font-size:.875rem;color:#065f46;font-weight:600; }
    .gps-error-box { background:#fee2e2;border:1px solid #fca5a5;border-radius:var(--radius);padding:1rem;font-size:.85rem;color:#991b1b; }

    .form-container { max-width:640px;margin:0 auto;background:var(--card-bg);border:1px solid var(--border);border-radius:var(--radius);padding:2rem;box-shadow:0 4px 6px -1px rgba(44,104,123,.06); }
    .page-body { background:var(--muted); }
  </style>
</head>
<body>

<?php include '../includes/sidebar.php'; ?>

<div class="main-content">
  <header class="topbar">
    <button class="sidebar-toggle" onclick="toggleSidebar()">&#9776;</button>
    <h2>Driver Panel</h2>
  </header>

  <main class="page-body" style="padding:1.75rem">
    <h1 class="page-title">Request Service</h1>

    <?php if ($message): ?>
      <div class="alert alert-success"><?= $message ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
      <div class="alert alert-error"><?= $error ?></div>
    <?php endif; ?>

    <div class="form-container">

      <!-- Step Indicator -->
      <div class="steps">
        <div class="step active" id="ind-1">
          <div class="step-circle">1</div>
          <div class="step-label">Choose Service</div>
        </div>
        <div class="step-line" id="line-1"></div>
        <div class="step" id="ind-2">
          <div class="step-circle">2</div>
          <div class="step-label">Your Location</div>
        </div>
        <div class="step-line" id="line-2"></div>
        <div class="step" id="ind-3">
          <div class="step-circle">3</div>
          <div class="step-label">Select Garage</div>
        </div>
      </div>

      <!-- STEP 1: Pick service -->
      <div class="panel active" id="panel-1">
        <p style="font-size:.875rem;color:var(--text-muted);margin-bottom:.5rem">What kind of help do you need?</p>
        <div class="service-grid">
          <div class="service-card" onclick="pickService('flat_tire','Flat Tire',this)">
            <div class="icon">🛞</div><div class="label">Flat Tire</div>
          </div>
          <div class="service-card" onclick="pickService('battery','Battery Jump',this)">
            <div class="icon">🔋</div><div class="label">Battery Jump</div>
          </div>
          <div class="service-card" onclick="pickService('towing','Towing',this)">
            <div class="icon">🚛</div><div class="label">Towing</div>
          </div>
          <div class="service-card" onclick="pickService('engine','Engine Repair',this)">
            <div class="icon">⚙️</div><div class="label">Engine Repair</div>
          </div>
          <div class="service-card" onclick="pickService('fuel','Fuel Delivery',this)">
            <div class="icon">⛽</div><div class="label">Fuel Delivery</div>
          </div>
        </div>
      </div>

      <!-- STEP 2: Auto GPS Location -->
      <div class="panel" id="panel-2">
        <p style="font-size:.875rem;color:var(--text-muted);margin-bottom:1rem">
          Detecting your location for <strong id="service-label"></strong>…
        </p>

        <!-- Detecting state -->
        <div id="gps-detecting" class="gps-detecting" style="display:none">
          <div class="spinner">📍</div>
          <p>Getting your location, please wait…</p>
        </div>

        <!-- Success state -->
        <div id="gps-success" class="gps-success" style="display:none">
          <div class="check">✅</div>
          <p id="gps-coords-text"></p>
        </div>

        <!-- Error state -->
        <div id="gps-error" class="gps-error-box" style="display:none">
          <strong>❌ Could not detect location.</strong>
          <p id="gps-error-msg" style="margin:.35rem 0 .75rem"></p>
          <button type="button" class="btn-location" onclick="getGPS()" style="margin:0">🔄 Try Again</button>
          <div style="margin-top:.75rem">
            <label style="font-size:.8rem;font-weight:600;color:#991b1b">Or enter manually:</label>
            <input type="text" id="step-location" placeholder="Street / landmark / area name"
              style="width:100%;margin-top:.35rem;padding:.5rem .75rem;border:1px solid #fca5a5;border-radius:var(--radius);font-size:.875rem">
          </div>
        </div>

        <div style="display:flex;gap:.6rem;margin-top:1.25rem">
          <button type="button" class="btn-back" onclick="goStep(1)">← Back</button>
          <button type="button" class="btn btn-primary" style="flex:1" id="btn-continue"
                  onclick="continueToGarages()" disabled>Find Nearby Garages →</button>
        </div>
      </div>

      <!-- STEP 3: Garage selection -->
      <div class="panel" id="panel-3">
        <p style="font-size:.875rem;color:var(--text-muted);margin-bottom:.25rem">
          Garages for <strong id="service-label2"></strong> near <strong id="location-label"></strong>:
        </p>
        <div id="garage-wrap">
          <div class="loading">⏳ No service selected yet.</div>
        </div>

        <div class="summary-box" id="summary">Select a garage to continue.</div>

        <form method="POST">
          <input type="hidden" name="garage_id"    id="f-garage-id">
          <input type="hidden" name="service_type" id="f-service-type">
          <input type="hidden" name="price"        id="f-price">
          <input type="hidden" name="location"     id="f-location">

          <div class="form-group">
            <label for="notes">Describe the Problem</label>
            <textarea name="notes" id="notes" rows="3"
                      placeholder="e.g. Front left tyre is flat near the highway exit…"></textarea>
          </div>

          <div style="display:flex;gap:.6rem;margin-top:1.25rem">
            <button type="button" class="btn-back" onclick="goStep(2)">← Back</button>
            <button type="submit" class="btn btn-primary" style="flex:1">Submit Request</button>
          </div>
        </form>
      </div>

    </div><!-- /form-container -->
  </main>
</div>

<script src="/roadside_ally_php/assets/js/main.js"></script>
<script>
  var selService = '', selServiceLabel = '', selGarageId = 0, selGarageName = '', selPrice = 0;
  var driverLat = null, driverLng = null;

  function goStep(n) {
    for (var i = 1; i <= 3; i++) {
      document.getElementById('panel-' + i).classList.toggle('active', i === n);
      var ind = document.getElementById('ind-' + i);
      ind.classList.remove('active','done');
      if (i < n)  ind.classList.add('done');
      if (i === n) ind.classList.add('active');
      var line = document.getElementById('line-' + i);
      if (line) line.classList.toggle('done', i < n);
    }
  }

  function pickService(type, label, el) {
    selService = type; selServiceLabel = label;
    document.querySelectorAll('.service-card').forEach(function(c){ c.classList.remove('selected'); });
    el.classList.add('selected');
    document.getElementById('service-label').textContent = label;
    goStep(2);
    // Auto-start GPS as soon as service is picked
    getGPS();
  }

  function getGPS() {
    // Reset all states
    document.getElementById('gps-detecting').style.display = 'none';
    document.getElementById('gps-success').style.display   = 'none';
    document.getElementById('gps-error').style.display     = 'none';
    document.getElementById('btn-continue').disabled       = true;

    if (!navigator.geolocation) {
      document.getElementById('gps-error').style.display = 'block';
      document.getElementById('gps-error-msg').textContent = 'Geolocation is not supported by your browser.';
      return;
    }

    // Show detecting spinner
    document.getElementById('gps-detecting').style.display = 'block';

    navigator.geolocation.getCurrentPosition(
      function(pos) {
        driverLat = pos.coords.latitude;
        driverLng = pos.coords.longitude;

        // Show success
        document.getElementById('gps-detecting').style.display = 'none';
        document.getElementById('gps-success').style.display   = 'block';
        document.getElementById('gps-coords-text').textContent =
          'Location detected: ' + driverLat.toFixed(4) + ', ' + driverLng.toFixed(4);
        document.getElementById('btn-continue').disabled = false;

        // Auto-proceed to garages after 1.2 seconds
        setTimeout(continueToGarages, 1200);
      },
      function(err) {
        document.getElementById('gps-detecting').style.display = 'none';
        document.getElementById('gps-error').style.display     = 'block';
        document.getElementById('gps-error-msg').textContent   = err.message;
        // Allow manual entry as fallback
        document.getElementById('btn-continue').disabled = false;
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  }

  function continueToGarages() {
    // Use GPS coords if available, else manual input
    var manualInput = document.getElementById('step-location');
    var manualValue = manualInput ? manualInput.value.trim() : '';

    if (!driverLat && !manualValue) {
      document.getElementById('gps-error').style.display = 'block';
      document.getElementById('gps-error-msg').textContent = 'Please allow location access or enter address manually.';
      return;
    }

    var displayLoc = driverLat
      ? 'My location (' + driverLat.toFixed(4) + ', ' + driverLng.toFixed(4) + ')'
      : manualValue;

    document.getElementById('f-location').value       = displayLoc;
    document.getElementById('f-service-type').value   = selService;
    document.getElementById('service-label2').textContent = selServiceLabel;
    document.getElementById('location-label').textContent = displayLoc;
    document.getElementById('summary').innerHTML =
      '<strong>Service:</strong> ' + esc(selServiceLabel) + '<br>' +
      '<strong>Location:</strong> ' + esc(displayLoc) + '<br>' +
      '<strong>Garage:</strong> not selected yet';
    goStep(3);
    loadGarages(selService);
  }

  function loadGarages(type) {
    var wrap = document.getElementById('garage-wrap');
    wrap.innerHTML = '<div class="loading">⏳ Finding nearby garages…</div>';
    var url = 'request.php?fetch_garages=1&service_type=' + encodeURIComponent(type);
    if (driverLat && driverLng) url += '&lat=' + driverLat + '&lng=' + driverLng;
    fetch(url)
      .then(function(r){ return r.json(); })
      .then(function(list) {
        if (!list.length) {
          wrap.innerHTML = '<div class="no-garages">😔 No garages offer <strong>' + esc(selServiceLabel) + '</strong> nearby.<br><small>Try a different service or check back later.</small></div>';
          return;
        }
        var html = '<div class="garage-list">';
        list.forEach(function(g) {
          var rating = Math.round(g.rating) || 0;
          var stars  = '★'.repeat(rating) + '☆'.repeat(5 - rating);
          var dist   = g.distance_km != null ? '<div class="g-dist">📍 ' + parseFloat(g.distance_km).toFixed(1) + ' km away</div>' : '';
          html += '<div class="garage-card" onclick="pickGarage(' + g.id + ',\'' + escJ(g.name) + '\',' + g.price + ',event)">' +
            '<div>' +
              '<div class="g-name">' + esc(g.name) + '</div>' +
              '<div class="g-meta">🏙 ' + esc(g.city || '') + (g.address ? ' · ' + esc(g.address) : '') + '</div>' +
              (g.phone ? '<div class="g-meta">📞 ' + esc(g.phone) + '</div>' : '') +
              '<div class="stars">' + stars + '</div>' +
              dist +
            '</div>' +
            '<div style="text-align:right;flex-shrink:0">' +
              '<div class="g-price">₹' + parseFloat(g.price).toFixed(0) + '</div>' +
              '<div class="g-time">⏱ ' + esc(g.estimated_time || '—') + '</div>' +
              '<div style="font-size:.75rem;color:var(--text-muted);margin-top:.2rem">' + esc(g.service_name) + '</div>' +
            '</div>' +
          '</div>';
        });
        html += '</div>';
        wrap.innerHTML = html;
      })
      .catch(function() {
        wrap.innerHTML = '<div class="alert alert-error">Failed to load garages. Please refresh and try again.</div>';
      });
  }

  function pickGarage(id, name, price, event) {
    selGarageId = id; selGarageName = name; selPrice = price;
    document.querySelectorAll('.garage-card').forEach(function(c){ c.classList.remove('selected'); });
    event.currentTarget.classList.add('selected');
    document.getElementById('f-garage-id').value = id;
    document.getElementById('f-price').value = price;
    document.getElementById('summary').innerHTML =
      '<strong>Service:</strong> ' + esc(selServiceLabel) + '<br>' +
      '<strong>Location:</strong> ' + esc(document.getElementById('f-location').value) + '<br>' +
      '<strong>Garage:</strong> ' + esc(name) + '<br>' +
      '<strong>Price:</strong> ₹' + parseFloat(price).toFixed(2);
  }

  function esc(s)  { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
  function escJ(s) { return String(s).replace(/\\/g,'\\\\').replace(/'/g,"\\'"); }
</script>
</body>
</html>