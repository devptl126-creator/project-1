<?php
require_once '../config.php';
requireRole('driver');
$uid = $_SESSION['user_id'];

// Handle cancel
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_request'])) {
    $rid = (int)$_POST['request_id'];
    $conn->query("UPDATE service_requests SET status='cancelled' WHERE id=$rid AND driver_id=$uid AND status='pending'");
    header('Location: tracking.php'); exit;
}

// Handle rating
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_rating'])) {
    $rid    = (int)$_POST['request_id'];
    $gid    = (int)$_POST['garage_id'];
    $stars  = min(5, max(1, (int)$_POST['stars']));
    // Save rating on request
    $conn->query("UPDATE service_requests SET driver_rating=$stars WHERE id=$rid AND driver_id=$uid");
    // Recalculate garage avg rating
    $res = $conn->query("SELECT AVG(driver_rating) as avg_r FROM service_requests WHERE garage_id=$gid AND driver_rating IS NOT NULL");
    $avg = $res->fetch_assoc()['avg_r'];
    $conn->query("UPDATE garages SET rating=".round($avg,1)." WHERE id=$gid");
    header('Location: tracking.php'); exit;
}

$request = $conn->query("
    SELECT sr.*, g.name as garage_name, g.id as gid
    FROM service_requests sr
    JOIN garages g ON g.id = sr.garage_id
    WHERE sr.driver_id = $uid
    ORDER BY sr.created_at DESC LIMIT 1
")->fetch_assoc();

$steps = ['pending'=>'Request Sent','accepted'=>'Accepted','mechanic_assigned'=>'Mechanic Assigned','in_progress'=>'In Progress','completed'=>'Completed'];
$order = array_keys($steps);
$current_index = $request ? array_search($request['status'], $order) : -1;
$is_active = $request && !in_array($request['status'], ['completed','cancelled']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Track Request – RoadRescue</title>
  <link rel="stylesheet" href="/roadside_ally_php/assets/css/driver.css">
  <style>
    .star-rating { display:flex; gap:.35rem; margin:.5rem 0; }
    .star-rating input { display:none; }
    .star-rating label { font-size:2rem; cursor:pointer; color:#d1d5db; transition:color .15s; }
    .star-rating input:checked ~ label,
    .star-rating label:hover,
    .star-rating label:hover ~ label { color:#f59e0b; }
    .star-rating { flex-direction:row-reverse; justify-content:flex-end; }
    .rating-box { background:var(--muted);border:1px solid var(--border);border-radius:var(--radius);padding:1.25rem;margin-top:1.25rem; }
    .btn-cancel { background:#ef4444;color:#fff;border:none;padding:.55rem 1.1rem;border-radius:var(--radius);font-weight:600;font-size:.875rem;cursor:pointer; }
    .btn-cancel:hover { background:#dc2626; }
    .pulse { animation: pulse 2s infinite; }
    @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.5} }
  </style>
</head>
<body>
<?php include '../includes/sidebar.php'; ?>
<div class="main-content">
  <header class="topbar">
    <button class="sidebar-toggle" onclick="toggleSidebar()">&#9776;</button>
    <h2>Driver Panel</h2>
  </header>
  <main class="page-body">
    <h1 class="page-title">Track Your Request</h1>

    <?php if (!$request): ?>
      <div class="card"><div class="card-body text-center text-muted">No requests yet.</div></div>

    <?php elseif ($request['status'] === 'cancelled'): ?>
      <div class="alert alert-error">❌ This request was cancelled. <a href="request.php">Make a new request</a>.</div>

    <?php else: ?>
    <!-- Status Timeline -->
    <div class="card" style="margin-bottom:1.5rem">
      <div class="card-header" style="text-align:left;display:flex;justify-content:space-between;align-items:center">
        <div>
          <strong><?= ucfirst(str_replace('_',' ',$request['service_type'])) ?></strong>
          <p style="font-size:.85rem;color:var(--text-muted);margin:0"><?= htmlspecialchars($request['location']) ?></p>
        </div>
        <?php if ($is_active): ?>
          <span class="pulse" style="font-size:.75rem;color:#10b981;font-weight:600">● Live</span>
        <?php endif; ?>
      </div>
      <div class="card-body">
        <div class="timeline">
          <?php foreach ($steps as $status => $label):
            $i = array_search($status, $order);
            $done   = $i <= $current_index;
            $active = $i === $current_index;
          ?>
          <div class="timeline-step">
            <div class="timeline-circle <?= $active ? 'tl-active' : ($done ? 'tl-done' : '') ?>">
              <?= $done ? '✓' : ($i+1) ?>
            </div>
            <p class="timeline-label"><?= $label ?></p>
          </div>
          <?php if ($status !== 'completed'): ?>
            <div class="timeline-line <?= $i < $current_index ? 'tl-line-done' : '' ?>"></div>
          <?php endif; ?>
          <?php endforeach; ?>
        </div>
      </div>
    </div>

    <!-- Details -->
    <div class="two-col-grid">
      <div class="card">
        <div class="card-header" style="text-align:left"><strong>Request Details</strong></div>
        <div class="card-body">
          <div class="detail-row"><span>Service</span><span><?= ucfirst(str_replace('_',' ',$request['service_type'])) ?></span></div>
          <div class="detail-row"><span>Garage</span><span><?= htmlspecialchars($request['garage_name']) ?></span></div>
          <div class="detail-row"><span>Location</span><span><?= htmlspecialchars($request['location']) ?></span></div>
          <div class="detail-row"><span>Price</span><strong>₹<?= number_format($request['price'],2) ?></strong></div>
        </div>
      </div>
      <div class="card">
        <div class="card-header" style="text-align:left"><strong>Status Info</strong></div>
        <div class="card-body">
          <div class="detail-row"><span>Status</span><span><?= ucfirst(str_replace('_',' ',$request['status'])) ?></span></div>
          <div class="detail-row"><span>Requested At</span><span><?= date('M d, h:i A', strtotime($request['created_at'])) ?></span></div>
          <div class="detail-row"><span>Last Update</span><span><?= date('M d, h:i A', strtotime($request['updated_at'])) ?></span></div>
        </div>
      </div>
    </div>

    <!-- Cancel Button (pending only) -->
    <?php if ($request['status'] === 'pending'): ?>
    <div class="card" style="margin-top:1rem">
      <div class="card-body">
        <form method="POST" onsubmit="return confirm('Cancel this request?')">
          <input type="hidden" name="request_id" value="<?= $request['id'] ?>">
          <button type="submit" name="cancel_request" class="btn-cancel">✖ Cancel Request</button>
        </form>
      </div>
    </div>
    <?php endif; ?>

    <!-- Rating Form (completed + not yet rated) -->
    <?php if ($request['status'] === 'completed' && empty($request['driver_rating'])): ?>
    <div class="rating-box">
      <strong>⭐ Rate your experience with <?= htmlspecialchars($request['garage_name']) ?></strong>
      <form method="POST" style="margin-top:.75rem">
        <input type="hidden" name="request_id" value="<?= $request['id'] ?>">
        <input type="hidden" name="garage_id"  value="<?= $request['gid'] ?>">
        <div class="star-rating">
          <?php for($s=5;$s>=1;$s--): ?>
            <input type="radio" name="stars" id="s<?=$s?>" value="<?=$s?>" <?=$s===5?'required':''?>>
            <label for="s<?=$s?>">★</label>
          <?php endfor; ?>
        </div>
        <button type="submit" name="submit_rating" class="btn btn-primary" style="margin-top:.75rem">Submit Rating</button>
      </form>
    </div>
    <?php elseif ($request['status'] === 'completed' && !empty($request['driver_rating'])): ?>
    <div class="rating-box">
      <strong>Your Rating:</strong> <?= str_repeat('★',$request['driver_rating']) ?><?= str_repeat('☆',5-$request['driver_rating']) ?>
    </div>
    <?php endif; ?>

    <?php endif; ?>
  </main>
</div>
<script src="/roadside_ally_php/assets/js/main.js"></script>
<?php if ($is_active ?? false): ?>
<script>
// Poll status every 15s without full reload
function pollStatus() {
  fetch('tracking_poll.php')
    .then(r => r.json())
    .then(d => { if (d.changed) location.reload(); })
    .catch(() => {});
}
setInterval(pollStatus, 15000);
</script>
<?php endif; ?>
</body>
</html>