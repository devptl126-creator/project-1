<?php
// driver/tracking_poll.php
// Called by JS every 15s — returns {changed: true} if status updated
require_once '../config.php';
requireRole('driver');
$uid = $_SESSION['user_id'];

$row = $conn->query("
    SELECT status, updated_at FROM service_requests
    WHERE driver_id=$uid AND status NOT IN ('completed','cancelled')
    ORDER BY created_at DESC LIMIT 1
")->fetch_assoc();

$last_seen = $_GET['since'] ?? '';
$changed   = false;

if ($row && $last_seen && $row['updated_at'] !== $last_seen) {
    $changed = true;
}

header('Content-Type: application/json');
echo json_encode([
    'changed'    => $changed,
    'status'     => $row['status'] ?? null,
    'updated_at' => $row['updated_at'] ?? null,
]);