<?php
require_once '../config.php';
requireRole('garage_owner');
$uid = $_SESSION['user_id'];

$garage = $conn->query("SELECT * FROM garages WHERE owner_id=$uid LIMIT 1")->fetch_assoc();
$requests = $mechanics = [];
$revenue = 0;

if ($garage) {
    $gid = $garage['id'];
    $requests  = $conn->query("SELECT sr.*, p.full_name as driver_name FROM service_requests sr JOIN profiles p ON p.user_id=sr.driver_id WHERE sr.garage_id=$gid ORDER BY sr.created_at DESC")->fetch_all(MYSQLI_ASSOC);
    $mechanics = $conn->query("SELECT COUNT(*) as c FROM mechanics WHERE garage_id=$gid")->fetch_assoc()['c'];
    $revenue   = $conn->query("SELECT COALESCE(SUM(price),0) as r FROM service_requests WHERE garage_id=$gid AND status='completed'")->fetch_assoc()['r'];
}

// ✅ FIX: replaced fn() arrow function with regular function (PHP 5.6+ compatible)
$active = array_filter($requests, function($r) {
    return !in_array($r['status'], ['completed', 'cancelled']);
});

$status_colors = ['pending'=>'badge-pending','accepted'=>'badge-blue','mechanic_assigned'=>'badge-blue','in_progress'=>'badge-yellow','completed'=>'badge-approved','cancelled'=>'badge-danger'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Garage Dashboard – RoadRescue</title>
  <link rel="stylesheet" href="/roadside_ally_php/assets/css/style.css">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>
<div class="main-content">
  <header class="topbar"><button class="sidebar-toggle" onclick="toggleSidebar()">&#9776;</button><h2>Garage Panel</h2></header>
  <main class="page-body">
    <h1 class="page-title">Garage Dashboard<?= $garage ? ' — '.htmlspecialchars($garage['name']) : '' ?></h1>
    <?php if ($garage && !$garage['is_approved']): ?>
      <div class="alert" style="background:#fefce8;color:#854d0e;border:1px solid #fde68a;margin-bottom:1rem">⏳ Your garage is pending admin approval.</div>
    <?php endif; ?>
    <?php if (!$garage): ?>
      <div class="alert alert-error">No garage found. Please set up your <a href="/roadside_ally_php/garage/profile.php">garage profile</a> first.</div>
    <?php else: ?>
    <div class="stats-grid" style="margin-bottom:1.5rem">
      <div class="stat-card"><div class="stat-icon icon-blue">📋</div><div><p class="stat-label">Total Requests</p><p class="stat-value"><?= count($requests) ?></p></div></div>
      <div class="stat-card"><div class="stat-icon icon-yellow">🔧</div><div><p class="stat-label">Active Jobs</p><p class="stat-value"><?= count($active) ?></p></div></div>
      <div class="stat-card"><div class="stat-icon icon-green">👥</div><div><p class="stat-label">Mechanics</p><p class="stat-value"><?= $mechanics ?></p></div></div>
      <div class="stat-card"><div class="stat-icon icon-cyan">₹</div><div><p class="stat-label">Revenue</p><p class="stat-value">₹<?= number_format($revenue,0) ?></p></div></div>
    </div>
    <div class="card">
      <div class="card-header" style="display:flex;justify-content:space-between;align-items:center;text-align:left">
        <strong>Recent Requests</strong>
        <a href="/roadside_ally_php/garage/requests.php" class="btn btn-sm" style="background:var(--muted);color:#0f172a">View All</a>
      </div>
      <div class="card-body" style="padding:0">
        <?php if (empty($requests)): ?>
          <p style="padding:1rem;color:var(--muted-fg)">No requests yet.</p>
        <?php else: foreach (array_slice($requests,0,5) as $r): ?>
          <div class="request-row">
            <div>
              <p><strong><?= ucfirst(str_replace('_',' ',$r['service_type'])) ?></strong> <span style="color:var(--muted-fg);font-size:0.85rem">by <?= htmlspecialchars($r['driver_name']) ?></span></p>
              <p style="font-size:0.82rem;color:var(--muted-fg)">📍 <?= htmlspecialchars($r['location']) ?> &nbsp;·&nbsp; ₹<?= number_format($r['price'],2) ?></p>
            </div>
            <span class="badge <?= $status_colors[$r['status']] ?>"><?= ucfirst(str_replace('_',' ',$r['status'])) ?></span>
          </div>
        <?php endforeach; endif; ?>
      </div>
    </div>
    <?php endif; ?>
  </main>
</div>
<script src="/roadside_ally_php/assets/js/main.js"></script>
</body>
</html>