<?php
require_once '../config.php';
requireRole('garage_owner');
$uid = $_SESSION['user_id'];

$garage = $conn->query("SELECT * FROM garages WHERE owner_id=$uid LIMIT 1")->fetch_assoc();
$msg = $error = '';

if ($garage) {
    $gid = $garage['id'];

    if (isset($_POST['add_mechanic'])) {
        $email  = trim($_POST['email']);
        $skills = trim($_POST['skills']);
        $user_row = $conn->query("SELECT u.id FROM users u WHERE u.email='".mysqli_real_escape_string($conn,$email)."' AND u.role='mechanic' LIMIT 1")->fetch_assoc();
        if (!$user_row) {
            $error = 'No mechanic found with that email.';
        } else {
            $mid = $user_row['id'];
            $skills_json = json_encode(array_filter(array_map('trim', explode(',', $skills))));
            $conn->query("UPDATE mechanics SET garage_id=$gid, skills='".mysqli_real_escape_string($conn,$skills_json)."' WHERE user_id=$mid");
            $msg = 'Mechanic added to your garage.';
        }
    }
    if (isset($_GET['remove'])) {
        $mid = (int)$_GET['remove'];
        $conn->query("UPDATE mechanics SET garage_id=NULL WHERE id=$mid AND garage_id=$gid");
        redirect('/roadside_ally_php/garage/mechanics.php');
    }

    $mechanics = $conn->query("SELECT m.id, m.is_available, m.skills, p.full_name, p.phone FROM mechanics m JOIN profiles p ON p.user_id=m.user_id WHERE m.garage_id=$gid")->fetch_all(MYSQLI_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Manage Mechanics – RoadRescue</title>
  <link rel="stylesheet" href="/roadside_ally_php/assets/css/style.css">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>
<div class="main-content">
  <header class="topbar"><button class="sidebar-toggle" onclick="toggleSidebar()">&#9776;</button><h2>Garage Panel</h2></header>
  <main class="page-body">
    <div class="page-header">
      <h1 class="page-title">Manage Mechanics</h1>
      <button class="btn btn-primary" onclick="document.getElementById('add-modal').style.display='flex'">+ Add Mechanic</button>
    </div>
    <?php if ($msg): ?><div class="alert alert-success"><?= $msg ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error"><?= $error ?></div><?php endif; ?>

    <div class="table-card">
      <table class="table">
        <thead><tr><th>Name</th><th>Phone</th><th>Skills</th><th>Status</th><th>Action</th></tr></thead>
        <tbody>
          <?php if (empty($mechanics)): ?>
            <tr><td colspan="5" class="text-center text-muted">No mechanics yet. Click "Add Mechanic" to get started.</td></tr>
          <?php else: foreach ($mechanics as $m): ?>
            <tr>
              <td><strong><?= htmlspecialchars($m['full_name']) ?></strong></td>
              <td><?= $m['phone'] ?: '—' ?></td>
              <td>
                <?php $skills = json_decode($m['skills'] ?? '[]', true); ?>
                <?php foreach ($skills as $s): ?><span class="service-tag"><?= htmlspecialchars($s) ?></span><?php endforeach; ?>
                <?php if (empty($skills)): ?>—<?php endif; ?>
              </td>
              <td><span class="badge <?= $m['is_available'] ? 'badge-approved' : 'badge-pending' ?>"><?= $m['is_available'] ? 'Available' : 'Busy' ?></span></td>
              <td><a href="?remove=<?= $m['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Remove mechanic?')">Remove</a></td>
            </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>

    <!-- Modal -->
    <div id="add-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.4);z-index:100;align-items:center;justify-content:center">
      <div class="card" style="width:100%;max-width:440px;margin:1rem">
        <div class="card-header" style="text-align:left;display:flex;justify-content:space-between">
          <strong>Add Mechanic</strong>
          <button onclick="document.getElementById('add-modal').style.display='none'" style="background:none;border:none;font-size:1.2rem;cursor:pointer">✕</button>
        </div>
        <div class="card-body">
          <p style="font-size:0.85rem;color:var(--muted-fg);margin-bottom:1rem">Enter the email of a registered mechanic.</p>
          <form method="POST">
            <div class="form-group"><label>Mechanic Email</label><input type="email" name="email" placeholder="mechanic@example.com" required></div>
            <div class="form-group"><label>Skills (comma separated)</label><input type="text" name="skills" placeholder="Engine Repair, Tire Change"></div>
            <button type="submit" name="add_mechanic" class="btn btn-primary btn-full">Add Mechanic</button>
          </form>
        </div>
      </div>
    </div>
  </main>
</div>
<script src="/roadside_ally_php/assets/js/main.js"></script>
</body>
</html>