<?php
require_once '../config.php';
requireRole('garage_owner');
$uid = $_SESSION['user_id'];
$garage = $conn->query("SELECT * FROM garages WHERE owner_id=$uid LIMIT 1")->fetch_assoc();
$msg = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = trim($_POST['name']);
    $phone   = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $city    = trim($_POST['city']);
    $hours   = trim($_POST['operating_hours']);
    $lat     = trim($_POST['latitude']);
    $lon     = trim($_POST['longitude']);
    $desc    = trim($_POST['description']);

    if ($garage) {
        $stmt = $conn->prepare("UPDATE garages SET name=?, phone=?, address=?, city=?, operating_hours=?, latitude=?, longitude=?, description=? WHERE id=?");
        $stmt->bind_param("ssssssssi", $name, $phone, $address, $city, $hours, $lat, $lon, $desc, $garage['id']);
        $stmt->execute() ? $msg = 'Garage profile updated.' : $error = 'Update failed: ' . $stmt->error;
        $garage = $conn->query("SELECT * FROM garages WHERE owner_id=$uid LIMIT 1")->fetch_assoc();
    } else {
        $stmt = $conn->prepare("INSERT INTO garages (owner_id, name, phone, address, city, operating_hours, latitude, longitude, description, is_approved) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0)");
        $stmt->bind_param("issssssss", $uid, $name, $phone, $address, $city, $hours, $lat, $lon, $desc);
        $stmt->execute() ? $msg = 'Garage created! Awaiting admin approval.' : $error = 'Failed: ' . $stmt->error;
        $garage = $conn->query("SELECT * FROM garages WHERE owner_id=$uid LIMIT 1")->fetch_assoc();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Garage Profile – RoadRescue</title>
  <link rel="stylesheet" href="/roadside_ally_php/assets/css/style.css">
  <style>
    #map-picker { width:100%; height:280px; border-radius:var(--radius); border:2px solid var(--border); margin-top:.5rem; cursor:crosshair; }
    .map-hint   { font-size:.75rem; color:var(--text-muted); margin-top:.3rem; }
    .btn-locate { background:none; border:1.5px solid var(--primary); color:var(--primary); padding:.4rem .9rem; border-radius:var(--radius); font-size:.8rem; font-weight:600; cursor:pointer; margin-bottom:.5rem; }
    .btn-locate:hover { background:var(--primary); color:#fff; }
  </style>
</head>
<body>
<?php include '../includes/sidebar.php'; ?>
<div class="main-content">
  <header class="topbar"><button class="sidebar-toggle" onclick="toggleSidebar()">&#9776;</button><h2>Garage Panel</h2></header>
  <main class="page-body">
    <h1 class="page-title">Garage Profile</h1>
    <?php if ($msg): ?><div class="alert alert-success"><?= $msg ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error"><?= $error ?></div><?php endif; ?>
    <div class="card" style="max-width:700px">
      <div class="card-header" style="text-align:left"><strong>Garage Information</strong></div>
      <div class="card-body">
        <form method="POST" id="garage-form">
          <div class="two-col-grid">
            <div class="form-group"><label>Garage Name</label><input type="text" name="name" value="<?= htmlspecialchars($garage['name'] ?? '') ?>" required></div>
            <div class="form-group"><label>Phone</label><input type="text" name="phone" value="<?= htmlspecialchars($garage['phone'] ?? '') ?>"></div>
            <div class="form-group"><label>Address</label><input type="text" name="address" id="inp-address" value="<?= htmlspecialchars($garage['address'] ?? '') ?>"></div>
            <div class="form-group"><label>City</label><input type="text" name="city" value="<?= htmlspecialchars($garage['city'] ?? '') ?>"></div>
            <div class="form-group"><label>Operating Hours</label><input type="text" name="operating_hours" value="<?= htmlspecialchars($garage['operating_hours'] ?? '') ?>" placeholder="e.g. 8am–8pm"></div>
          </div>

          <!-- Map Picker -->
          <div class="form-group" style="margin-top:.75rem">
            <label>Garage Location (click map to pin)</label>
            <button type="button" class="btn-locate" onclick="locateMe()">📍 Use My Location</button>
            <div id="map-picker"></div>
            <p class="map-hint">Click anywhere on the map to set the pin, or use the button above.</p>
          </div>

          <div class="two-col-grid" style="margin-top:.5rem">
            <div class="form-group"><label>Latitude</label><input type="text" name="latitude" id="inp-lat" value="<?= htmlspecialchars($garage['latitude'] ?? '') ?>" placeholder="e.g. 20.9876" readonly></div>
            <div class="form-group"><label>Longitude</label><input type="text" name="longitude" id="inp-lng" value="<?= htmlspecialchars($garage['longitude'] ?? '') ?>" placeholder="e.g. 72.9876" readonly></div>
          </div>

          <div class="form-group">
            <label>Description</label>
            <textarea name="description" rows="4" placeholder="Describe services, specialization, capacity…"><?= htmlspecialchars($garage['description'] ?? '') ?></textarea>
          </div>
          <button type="submit" class="btn btn-primary">Save Changes</button>
        </form>
      </div>
    </div>
  </main>
</div>
<script src="/roadside_ally_php/assets/js/main.js"></script>

<!-- Leaflet (no API key needed) -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
  var initLat = <?= json_encode($garage['latitude'] ?? 23.0225) ?>;
  var initLng = <?= json_encode($garage['longitude'] ?? 72.5714) ?>;

  var map    = L.map('map-picker').setView([initLat, initLng], 13);
  var marker = null;

  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap'
  }).addTo(map);

  // Show existing pin if coords saved
  if (<?= ($garage['latitude'] ?? 0) ? 'true' : 'false' ?>) {
    marker = L.marker([initLat, initLng]).addTo(map);
  }

  map.on('click', function(e) {
    setPin(e.latlng.lat, e.latlng.lng);
  });

  function setPin(lat, lng) {
    if (marker) map.removeLayer(marker);
    marker = L.marker([lat, lng]).addTo(map);
    document.getElementById('inp-lat').value = lat.toFixed(6);
    document.getElementById('inp-lng').value = lng.toFixed(6);
  }

  function locateMe() {
    if (!navigator.geolocation) return alert('Geolocation not supported.');
    navigator.geolocation.getCurrentPosition(function(pos) {
      var lat = pos.coords.latitude, lng = pos.coords.longitude;
      map.setView([lat, lng], 15);
      setPin(lat, lng);
    }, function() {
      alert('Could not get your location.');
    });
  }
</script>
</body>
</html>