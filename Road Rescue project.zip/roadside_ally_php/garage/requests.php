<?php
require_once '../config.php';
requireRole('garage_owner');
$uid = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT * FROM garages WHERE owner_id = ? LIMIT 1");
$stmt->bind_param("i", $uid);
$stmt->execute();
$garage = $stmt->get_result()->fetch_assoc();

$msg = '';
$requests = [];
$mechanics = [];

if ($garage) {
    $gid = $garage['id'];

    if (isset($_POST['accept'])) {
        $rid = (int)$_POST['request_id'];
        $s = $conn->prepare("UPDATE service_requests SET status='accepted' WHERE id=? AND garage_id=?");
        $s->bind_param("ii", $rid, $gid); $s->execute();
        $msg = '✅ Request accepted.';
    }

    if (isset($_POST['reject'])) {
        $rid = (int)$_POST['request_id'];
        $s = $conn->prepare("UPDATE service_requests SET status='cancelled' WHERE id=? AND garage_id=?");
        $s->bind_param("ii", $rid, $gid); $s->execute();
        $msg = 'Request rejected.';
    }

    if (isset($_POST['assign'])) {
        $rid = (int)$_POST['request_id'];
        $mid = (int)$_POST['mechanic_id'];
        $s = $conn->prepare("UPDATE service_requests SET mechanic_id=?, status='mechanic_assigned' WHERE id=? AND garage_id=?");
        $s->bind_param("iii", $mid, $rid, $gid); $s->execute();
        $msg = '✅ Mechanic assigned.';
    }

    if (isset($_POST['mark_inprogress'])) {
        $rid = (int)$_POST['request_id'];
        $s = $conn->prepare("UPDATE service_requests SET status='in_progress' WHERE id=? AND garage_id=?");
        $s->bind_param("ii", $rid, $gid); $s->execute();
        $msg = '✅ Marked as In Progress.';
    }

    if (isset($_POST['mark_complete'])) {
        $rid = (int)$_POST['request_id'];
        $s = $conn->prepare("UPDATE service_requests SET status='completed' WHERE id=? AND garage_id=?");
        $s->bind_param("ii", $rid, $gid); $s->execute();
        $msg = '✅ Marked as Completed.';
    }

    // AJAX poll: return pending count
    if (isset($_GET['poll'])) {
        $res = $conn->query("SELECT COUNT(*) as cnt FROM service_requests WHERE garage_id=$gid AND status='pending'");
        header('Content-Type: application/json');
        echo json_encode($res->fetch_assoc());
        exit;
    }

    $req_stmt = $conn->prepare("
        SELECT sr.*, p.full_name as driver_name
        FROM service_requests sr
        JOIN profiles p ON p.user_id = sr.driver_id
        WHERE sr.garage_id = ?
        ORDER BY FIELD(sr.status,'pending','accepted','mechanic_assigned','in_progress','completed','cancelled'), sr.created_at DESC
    ");
    $req_stmt->bind_param("i", $gid);
    $req_stmt->execute();
    $requests = $req_stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    $mech_stmt = $conn->prepare("SELECT m.id, p.full_name FROM mechanics m JOIN profiles p ON p.user_id = m.user_id WHERE m.garage_id = ? AND m.is_available = 1");
    $mech_stmt->bind_param("i", $gid);
    $mech_stmt->execute();
    $mechanics = $mech_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

$status_colors = [
    'pending'           => 'badge-pending',
    'accepted'          => 'badge-blue',
    'mechanic_assigned' => 'badge-blue',
    'in_progress'       => 'badge-yellow',
    'completed'         => 'badge-approved',
    'cancelled'         => 'badge-danger'
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Incoming Requests – RoadRescue</title>
  <link rel="stylesheet" href="/roadside_ally_php/assets/css/style.css">
  <style>
    .new-badge { background:#ef4444;color:#fff;font-size:.65rem;font-weight:700;padding:.15rem .45rem;border-radius:999px;margin-left:.4rem;animation:pulse 1.5s infinite; }
    @keyframes pulse{0%,100%{opacity:1}50%{opacity:.5}}
    .action-row { display:flex;gap:.5rem;flex-wrap:wrap;align-items:center;margin-top:.6rem; }
    .btn-sm-red { background:#ef4444;color:#fff;border:none;padding:.35rem .75rem;border-radius:var(--radius);font-size:.75rem;font-weight:600;cursor:pointer; }
    .btn-sm-red:hover { background:#dc2626; }
    .btn-sm-green { background:#10b981;color:#fff;border:none;padding:.35rem .75rem;border-radius:var(--radius);font-size:.75rem;font-weight:600;cursor:pointer; }
    .btn-sm-green:hover { background:#059669; }
    .poll-bar { background:var(--muted);border-bottom:1px solid var(--border);padding:.5rem 1.5rem;font-size:.8rem;color:var(--text-muted);display:flex;align-items:center;gap:.5rem; }
    .poll-dot { width:8px;height:8px;background:#10b981;border-radius:50%;animation:pulse 2s infinite; }
  </style>
</head>
<body>
<?php include '../includes/sidebar.php'; ?>
<div class="main-content">
  <header class="topbar">
    <button class="sidebar-toggle" onclick="toggleSidebar()">&#9776;</button>
    <h2>Garage Panel</h2>
  </header>

  <!-- Live poll indicator -->
  <div class="poll-bar">
    <span class="poll-dot"></span>
    <span id="poll-txt">Checking for new requests every 20s…</span>
  </div>

  <main class="page-body">
    <h1 class="page-title">Incoming Requests <span id="new-count"></span></h1>

    <?php if ($msg): ?>
      <div class="alert alert-success"><?= $msg ?></div>
    <?php endif; ?>

    <?php if (!$garage): ?>
      <div class="alert alert-error">No garage linked to your account. Set up your <a href="/roadside_ally_php/garage/profile.php">garage profile</a>.</div>
    <?php elseif (empty($requests)): ?>
      <div class="card"><div class="card-body text-center text-muted" style="padding:2rem">No service requests yet.</div></div>
    <?php else: ?>
      <?php foreach ($requests as $r): ?>
        <div class="card" style="margin-bottom:1rem" id="req-<?= $r['id'] ?>">
          <div class="card-body">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:.75rem">
              <div>
                <div style="display:flex;align-items:center;gap:.65rem;margin-bottom:.2rem">
                  <strong style="font-size:1rem"><?= ucfirst(str_replace('_',' ',$r['service_type'])) ?></strong>
                  <span class="badge <?= $status_colors[$r['status']] ?? 'badge-pending' ?>"><?= ucfirst(str_replace('_',' ',$r['status'])) ?></span>
                  <?php if ($r['status'] === 'pending'): ?>
                    <span class="new-badge">NEW</span>
                  <?php endif; ?>
                </div>
                <p style="font-size:.84rem;color:var(--text-muted);margin:.1rem 0">👤 <?= htmlspecialchars($r['driver_name'] ?? 'Unknown') ?> &nbsp;·&nbsp; ₹<?= number_format($r['price']??0,2) ?></p>
                <p style="font-size:.84rem;color:var(--text-muted);margin:.1rem 0">📍 <?= htmlspecialchars($r['location']) ?></p>
                <?php if (!empty($r['notes'])): ?>
                  <p style="font-size:.82rem;color:var(--text-muted);margin:.1rem 0">📝 <?= htmlspecialchars($r['notes']) ?></p>
                <?php endif; ?>
                <p style="font-size:.75rem;color:var(--text-muted);margin:.25rem 0 0"><?= date('M d, Y h:i A', strtotime($r['created_at'])) ?></p>
                <?php if (!empty($r['driver_rating'])): ?>
                  <p style="font-size:.78rem;margin:.25rem 0 0">Driver rated: <?= str_repeat('★',$r['driver_rating']) ?></p>
                <?php endif; ?>
              </div>

              <div class="action-row">
                <?php if ($r['status'] === 'pending'): ?>
                  <form method="POST">
                    <input type="hidden" name="request_id" value="<?= $r['id'] ?>">
                    <button name="accept" class="btn btn-primary btn-sm">✔ Accept</button>
                  </form>
                  <form method="POST" onsubmit="return confirm('Reject this request?')">
                    <input type="hidden" name="request_id" value="<?= $r['id'] ?>">
                    <button name="reject" class="btn-sm-red">✖ Reject</button>
                  </form>
                <?php endif; ?>

                <?php if (in_array($r['status'],['accepted','mechanic_assigned']) && !empty($mechanics)): ?>
                  <form method="POST" style="display:flex;gap:.4rem">
                    <input type="hidden" name="request_id" value="<?= $r['id'] ?>">
                    <select name="mechanic_id" class="filter-select" required>
                      <option value="">Assign mechanic</option>
                      <?php foreach ($mechanics as $m): ?>
                        <option value="<?= $m['id'] ?>"><?= htmlspecialchars($m['full_name']) ?></option>
                      <?php endforeach; ?>
                    </select>
                    <button name="assign" class="btn btn-primary btn-sm">Assign</button>
                  </form>
                <?php endif; ?>

                <?php if ($r['status'] === 'mechanic_assigned'): ?>
                  <form method="POST">
                    <input type="hidden" name="request_id" value="<?= $r['id'] ?>">
                    <button name="mark_inprogress" class="btn-sm-green">▶ Start Work</button>
                  </form>
                <?php endif; ?>

                <?php if ($r['status'] === 'in_progress'): ?>
                  <form method="POST">
                    <input type="hidden" name="request_id" value="<?= $r['id'] ?>">
                    <button name="mark_complete" class="btn-sm-green">✔ Mark Complete</button>
                  </form>
                <?php endif; ?>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </main>
</div>
<script src="/roadside_ally_php/assets/js/main.js"></script>
<script>
var knownPending = <?= count(array_filter($requests, fn($r) => $r['status']==='pending')) ?>;
function pollRequests() {
  fetch('requests.php?poll=1')
    .then(r => r.json())
    .then(d => {
      document.getElementById('poll-txt').textContent = 'Live – last checked ' + new Date().toLocaleTimeString();
      if (d.cnt > knownPending) {
        document.getElementById('new-count').innerHTML = '<span class="new-badge">' + d.cnt + ' new</span>';
        location.reload();
      }
    }).catch(() => {});
}
setInterval(pollRequests, 20000);
</script>
</body>
</html>