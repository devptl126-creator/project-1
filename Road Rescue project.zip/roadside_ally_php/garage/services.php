<?php
require_once '../config.php';
requireRole('garage_owner');
$uid = $_SESSION['user_id'];

$garage = $conn->query("SELECT * FROM garages WHERE owner_id=$uid LIMIT 1")->fetch_assoc();
$msg = $error = '';

if ($garage) {
    $gid = $garage['id'];

    if (isset($_POST['add_service'])) {
        $type  = $_POST['service_type'];
        $name  = trim($_POST['name']);
        $price = (float)$_POST['price'];
        $time  = trim($_POST['estimated_time']);
        $stmt  = $conn->prepare("INSERT INTO garage_services (garage_id,service_type,name,price,estimated_time) VALUES (?,?,?,?,?)");
        $stmt->bind_param("issds", $gid, $type, $name, $price, $time);
        $stmt->execute() ? $msg = 'Service added.' : $error = 'Failed to add service.';
    }
    if (isset($_GET['remove'])) {
        $sid = (int)$_GET['remove'];
        $conn->query("DELETE FROM garage_services WHERE id=$sid AND garage_id=$gid");
        redirect('/roadside_ally_php/garage/services.php');
    }

    $services = $conn->query("SELECT * FROM garage_services WHERE garage_id=$gid ORDER BY created_at DESC")->fetch_all(MYSQLI_ASSOC);
}

$service_types = ['flat_tire'=>'Flat Tire','battery'=>'Battery','towing'=>'Towing','engine'=>'Engine','fuel'=>'Fuel Delivery'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Manage Services – RoadRescue</title>
  <link rel="stylesheet" href="/roadside_ally_php/assets/css/style.css">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>
<div class="main-content">
  <header class="topbar"><button class="sidebar-toggle" onclick="toggleSidebar()">&#9776;</button><h2>Garage Panel</h2></header>
  <main class="page-body">
    <div class="page-header">
      <h1 class="page-title">Manage Services</h1>
      <button class="btn btn-primary" onclick="document.getElementById('add-modal').style.display='flex'">+ Add Service</button>
    </div>
    <?php if ($msg): ?><div class="alert alert-success"><?= $msg ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error"><?= $error ?></div><?php endif; ?>

    <div class="table-card">
      <table class="table">
        <thead><tr><th>Service</th><th>Type</th><th>Price</th><th>Est. Time</th><th>Action</th></tr></thead>
        <tbody>
          <?php if (empty($services)): ?>
            <tr><td colspan="5" class="text-center text-muted">No services yet.</td></tr>
          <?php else: foreach ($services as $s): ?>
            <tr>
              <td><strong><?= htmlspecialchars($s['name']) ?></strong></td>
              <td><?= ucfirst(str_replace('_',' ',$s['service_type'])) ?></td>
              <td>₹<?= number_format($s['price'],2) ?></td>
              <td><?= htmlspecialchars($s['estimated_time'] ?? '—') ?></td>
              <td><a href="?remove=<?= $s['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Remove service?')">Remove</a></td>
            </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>

    <!-- Modal -->
    <div id="add-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.4);z-index:100;align-items:center;justify-content:center">
      <div class="card" style="width:100%;max-width:440px;margin:1rem">
        <div class="card-header" style="text-align:left;display:flex;justify-content:space-between">
          <strong>Add New Service</strong>
          <button onclick="document.getElementById('add-modal').style.display='none'" style="background:none;border:none;font-size:1.2rem;cursor:pointer">✕</button>
        </div>
        <div class="card-body">
          <form method="POST">
            <div class="form-group">
              <label>Service Type</label>
              <select name="service_type" required>
                <option value="">Select type</option>
                <?php foreach ($service_types as $k=>$v): ?><option value="<?= $k ?>"><?= $v ?></option><?php endforeach; ?>
              </select>
            </div>
            <div class="form-group"><label>Service Name</label><input type="text" name="name" placeholder="e.g. Flat Tire Fix" required></div>
            <div class="form-group"><label>Price (₹)</label><input type="number" name="price" placeholder="500" required></div>
            <div class="form-group"><label>Estimated Time</label><input type="text" name="estimated_time" placeholder="30 min"></div>
            <button type="submit" name="add_service" class="btn btn-primary btn-full">Add Service</button>
          </form>
        </div>
      </div>
    </div>
  </main>
</div>
<script src="/roadside_ally_php/assets/js/main.js"></script>
</body>
</html>