<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$role = $_SESSION['role'] ?? 'admin'; 
$name = $_SESSION['full_name'] ?? 'John Smith';

$nav = [
  'admin' => [
    ['label' => 'Dashboard',      'url' => '/roadside_ally_php/admin/dashboard.php',  'icon' => '🏠', 'type' => 'link'],
    [
      'label' => 'Manage Users', 
      'icon' => '👥', 
      'type' => 'dropdown', 
      'id' => 'dropdown-users',
      'children' => [
        ['label' => 'Manage Garages', 'url' => '/roadside_ally_php/admin/garages.php'],
        ['label' => 'Manage Drivers', 'url' => '/roadside_ally_php/admin/users.php?role=driver']
      ]
    ],
    [
      'label' => 'Active Requests', 
      'icon' => '📋', 
      'type' => 'dropdown', 
      'id' => 'dropdown-requests',
      'children' => [
        ['label' => 'Driver Request', 'url' => '/roadside_ally_php/admin/requests.php'],
        ['label' => 'Garage Request', 'url' => '/roadside_ally_php/admin/requests.php']
      ]
    ],
    ['label' => 'Settings',       'url' => '/roadside_ally_php/admin/settings.php',    'icon' => '⚙️', 'type' => 'link'],
  ],
  'driver' => [
    ['label' => 'Dashboard',       'url' => '/roadside_ally_php/driver/dashboard.php', 'icon' => '🏠'],
    ['label' => 'Request Service', 'url' => '/roadside_ally_php/driver/request.php',   'icon' => '➕'],
    ['label' => 'Track Request',   'url' => '/roadside_ally_php/driver/tracking.php',  'icon' => '📍'],
    ['label' => 'History',         'url' => '/roadside_ally_php/driver/history.php',   'icon' => '🕓'],
    ['label' => 'Profile',         'url' => '/roadside_ally_php/driver/profile.php',   'icon' => '👤'],
  ],
  'garage_owner' => [
    ['label' => 'Dashboard',          'url' => '/roadside_ally_php/garage/dashboard.php',        'icon' => '🏠'],
    ['label' => 'Driver Requests',    'url' => '/roadside_ally_php/garage/requests.php',         'icon' => '📋'],
    ['label' => 'Manage Mechanics',   'url' => '/roadside_ally_php/garage/mechanics.php',        'icon' => '🔧'],
    ['label' => 'Manage Services',    'url' => '/roadside_ally_php/garage/services.php',         'icon' => '⚙️'],
    ['label' => 'Garage Profile',     'url' => '/roadside_ally_php/garage/profile.php',          'icon' => '🏪'],
  ],
  'mechanic' => [
    ['label' => 'Dashboard',    'url' => '/roadside_ally_php/mechanic/dashboard.php', 'icon' => '🏠'],
    ['label' => 'Join Garage',  'url' => '/roadside_ally_php/mechanic/profile.php',   'icon' => '🏪'],
    ['label' => 'Incoming Jobs','url' => '/roadside_ally_php/mechanic/incoming.php',  'icon' => '📋'],
    ['label' => 'Current Job',  'url' => '/roadside_ally_php/mechanic/job.php',       'icon' => '🔧'],
    ['label' => 'Job History',  'url' => '/roadside_ally_php/mechanic/history.php',   'icon' => '🕓'],
  ],
];

$items = $nav[$role] ?? [];
$current = $_SERVER['REQUEST_URI'];
?>
<div class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M19 17H5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2Z"/><path d="M9 17v2"/><path d="M15 17v2"/></svg>
    <span>RoadRescue</span>
  </div>
  <nav class="sidebar-nav">
    <p class="sidebar-section-label"><?= ucfirst(str_replace('_', ' ', $role)) ?> Menu</p>
    <?php foreach ($items as $item): ?>
      <?php if (isset($item['type']) && $item['type'] === 'dropdown'): ?>
        <div class="sidebar-dropdown-container">
          <a href="javascript:void(0)" class="sidebar-link">
            <span><?= $item['icon'] ?></span>
            <span><?= $item['label'] ?></span>
            <span style="margin-left:auto; font-size: 0.55rem;">▼</span>
          </a>
          <div class="sidebar-dropdown-menu">
            <?php foreach ($item['children'] as $child): ?>
              <a href="<?= $child['url'] ?>" class="sidebar-link sidebar-sublink <?= strpos($current, basename($child['url'], '.php')) !== false ? 'active' : '' ?>">
                <span><?= $child['label'] ?></span>
              </a>
            <?php endforeach; ?>
          </div>
        </div>
      <?php else: ?>
        <a href="<?= $item['url'] ?>" class="sidebar-link <?= strpos($current, basename($item['url'], '.php')) !== false ? 'active' : '' ?>">
          <span><?= $item['icon'] ?></span>
          <span><?= $item['label'] ?></span>
        </a>
      <?php endif; ?>
    <?php endforeach; ?>
  </nav>
  <div class="sidebar-footer">
    <p class="sidebar-user"><?= htmlspecialchars($name) ?></p>
    <a href="/roadside_ally_php/logout.php" class="sidebar-logout">🚪 Log Out</a>
  </div>
</div>