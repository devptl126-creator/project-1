<?php
require_once '../config.php';
requireRole('mechanic');
$uid = $_SESSION['user_id'];

// Check if the mechanic is linked to a garage
$mech_check = $conn->query("SELECT garage_id, is_available FROM mechanics WHERE user_id = $uid LIMIT 1")->fetch_assoc();
$joined_garage = !empty($mech_check['garage_id']);
$is_available = $mech_check['is_available'] ?? 0;

$requests_count = 0;

if ($joined_garage) {
    // Get assigned jobs count
    $req_count_res = $conn->query("SELECT COUNT(*) as c FROM service_requests WHERE mechanic_id = (SELECT id FROM mechanics WHERE user_id = $uid)")->fetch_assoc();
    $requests_count = $req_count_res['c'] ?? 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mechanic Dashboard – RoadRescue</title>
  <link rel="stylesheet" href="/roadside_ally_php/assets/css/mechanic.css">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>

<div class="main-content">
  <header class="topbar">
    <button class="sidebar-toggle" onclick="toggleSidebar()">&#9776;</button>
    <h2>Mechanic Panel</h2>
  </header>
  
  <main class="page-body">
    <h1 class="page-title">Mechanic Dashboard</h1>

    <?php if (!$joined_garage): ?>
      <div class="alert alert-error">
        <strong>Notice:</strong> You are not joined to any garage yet. Please join a garage using the form below before continuing.
      </div>
      <div class="card" style="max-width: 600px;">
        <div class="card-header" style="text-align:left;">
          <strong>Join a Garage</strong>
        </div>
        <div class="card-body">
          <p style="margin-bottom: 1.25rem; color: var(--text-muted);">You need to join a garage to access the mechanic tools and receive service requests.</p>
          <a href="/roadside_ally_php/mechanic/profile.php" class="btn btn-primary btn-full">Join Garage</a>
        </div>
      </div>
    <?php else: ?>
      <div class="stats-grid" style="margin-bottom:1.5rem">
        <div class="stat-card">
          <div class="stat-icon icon-blue">📋</div>
          <div>
            <p class="stat-label">My Assigned Jobs</p>
            <p class="stat-value"><?= $requests_count ?></p>
          </div>
        </div>
        
        <div class="stat-card">
          <div class="stat-icon icon-green">⚙️</div>
          <div>
            <p class="stat-label">Availability Status</p>
            <p class="stat-value"><?= $is_available ? 'Available' : 'Busy' ?></p>
          </div>
        </div>
      </div>
      
      <div class="card">
        <div class="card-header" style="text-align:left">
          <strong>Quick Actions</strong>
        </div>
        <div class="card-body">
          <p style="margin-bottom:1rem; color:var(--text-muted);">View incoming jobs or update your current working status.</p>
          <div style="display:flex; gap:0.5rem;">
            <a href="/roadside_ally_php/mechanic/incoming.php" class="btn btn-primary">View Incoming Jobs</a>
            <a href="/roadside_ally_php/mechanic/job.php" class="btn" style="background:var(--muted); color:var(--primary)">Track Current Job</a>
          </div>
        </div>
      </div>
    <?php endif; ?>
    
  </main>
</div>

<script src="/roadside_ally_php/assets/js/main.js"></script>
</body>
</html>