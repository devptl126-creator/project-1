<?php
require_once '../config.php';
requireRole('mechanic');
$uid = $_SESSION['user_id'];

$mechanic = $conn->query("SELECT * FROM mechanics WHERE user_id=$uid LIMIT 1")->fetch_assoc();
$jobs = [];

if ($mechanic) {
    $mid  = $mechanic['id'];
    $jobs = $conn->query("
        SELECT sr.*, g.name as garage_name
        FROM service_requests sr
        JOIN garages g ON g.id=sr.garage_id
        WHERE sr.mechanic_id=$mid AND sr.status='completed'
        ORDER BY sr.created_at DESC
    ")->fetch_all(MYSQLI_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Job History – RoadRescue</title>
  <link rel="stylesheet" href="/roadside_ally_php/assets/css/mechanic.css">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>
<div class="main-content">
  <header class="topbar"><button class="sidebar-toggle" onclick="toggleSidebar()">&#9776;</button><h2>Mechanic Panel</h2></header>
  <main class="page-body">
    <h1 class="page-title">Job History</h1>
    <div class="table-card">
      <table class="table">
        <thead><tr><th>Service</th><th>Garage</th><th>Location</th><th>Price</th><th>Date</th></tr></thead>
        <tbody>
          <?php if (empty($jobs)): ?>
            <tr><td colspan="5" class="text-center text-muted">No completed jobs yet.</td></tr>
          <?php else: foreach ($jobs as $j): ?>
            <tr>
              <td><strong><?= ucfirst(str_replace('_',' ',$j['service_type'])) ?></strong></td>
              <td><?= htmlspecialchars($j['garage_name']) ?></td>
              <td><?= htmlspecialchars($j['location']) ?></td>
              <td>₹<?= number_format($j['price'],2) ?></td>
              <td><?= date('M d, Y',strtotime($j['created_at'])) ?></td>
            </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </main>
</div>
<script src="/roadside_ally_php/assets/js/main.js"></script>
</body>
</html>