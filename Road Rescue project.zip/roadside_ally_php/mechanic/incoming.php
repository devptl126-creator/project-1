<?php
require_once '../config.php';
requireRole('mechanic');
$uid = $_SESSION['user_id'];

$mech_row = $conn->query("SELECT id FROM mechanics WHERE user_id = $uid LIMIT 1")->fetch_assoc();
$mid = $mech_row['id'] ?? 0;
$msg = $error = '';

if ($mid > 0) {
    if (isset($_POST['accept_job'])) {
        $request_id = (int)$_POST['request_id'];
        
        $conn->begin_transaction();
        try {
            // Mechanic accepts the request -> updates status to accepted/in_progress automatically
            $conn->query("UPDATE service_requests SET status = 'accepted' WHERE id = $request_id");
            $conn->commit();
            $msg = 'Job accepted successfully. Service request is now approved.';
        } catch (Exception $e) {
            $conn->rollback();
            $error = 'Failed to accept job.';
        }
    }

    if (isset($_POST['decline_job'])) {
        $request_id = (int)$_POST['request_id'];
        
        $conn->begin_transaction();
        try {
            // Mechanic declines -> updates status to cancelled or rejected
            $conn->query("UPDATE service_requests SET status = 'cancelled' WHERE id = $request_id");
            $conn->commit();
            $msg = 'Job declined.';
        } catch (Exception $e) {
            $conn->rollback();
            $error = 'Failed to decline job.';
        }
    }

    $requests = $conn->query("SELECT sr.*, p.full_name as driver_name, g.name as garage_name 
                              FROM service_requests sr 
                              JOIN profiles p ON p.user_id = sr.driver_id 
                              JOIN garages g ON g.id = sr.garage_id 
                              WHERE sr.mechanic_id = $mid AND sr.status = 'mechanic_assigned' 
                              ORDER BY sr.created_at DESC")->fetch_all(MYSQLI_ASSOC);
} else {
    $requests = [];
    $error = 'Mechanic profile not linked.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Incoming Jobs – RoadRescue</title>
  <link rel="stylesheet" href="/roadside_ally_php/assets/css/mechanic.css">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>
<div class="main-content">
  <header class="topbar">
    <button class="sidebar-toggle" onclick="toggleSidebar()">&#9776;</button>
    <h2>Mechanic Panel</h2>
  </header>
  <main class="page-body">
    <h1 class="page-title">Incoming Job Requests</h1>
    
    <?php if ($msg): ?><div class="alert alert-success"><?= $msg ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error"><?= $error ?></div><?php endif; ?>

    <?php if (empty($requests)): ?>
      <div class="card">
        <div class="card-body text-center text-muted" style="padding:2rem;">No incoming jobs at the moment.</div>
      </div>
    <?php else: foreach ($requests as $r): ?>
      <div class="card" style="margin-bottom:1.25rem;">
        <div class="card-body">
          <div style="display:flex; justify-content:space-between; align-items:center; gap:1rem;">
            <div>
              <p><strong>Garage:</strong> <?= htmlspecialchars($r['garage_name']) ?></p>
              <p><strong>Driver:</strong> <?= htmlspecialchars($r['driver_name']) ?></p>
              <p style="font-size:0.875rem; color:var(--text-muted)">📍 <?= htmlspecialchars($r['location']) ?> &middot; <?= ucfirst(str_replace('_', ' ', $r['service_type'])) ?></p>
            </div>
            <div style="display:flex; gap:0.5rem;">
              <form method="POST">
                <input type="hidden" name="request_id" value="<?= $r['id'] ?>">
                <button type="submit" name="accept_job" class="btn btn-primary btn-sm">Accept</button>
              </form>
              <form method="POST">
                <input type="hidden" name="request_id" value="<?= $r['id'] ?>">
                <button type="submit" name="decline_job" class="btn btn-danger btn-sm">Decline</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    <?php endforeach; endif; ?>
  </main>
</div>
<script src="/roadside_ally_php/assets/js/main.js"></script>
</body>
</html>