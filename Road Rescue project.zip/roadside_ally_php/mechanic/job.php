<?php
require_once '../config.php';
requireRole('mechanic');
$uid = $_SESSION['user_id'];

$mech_row = $conn->query("SELECT id FROM mechanics WHERE user_id = $uid LIMIT 1")->fetch_assoc();
$mid = $mech_row['id'] ?? 0;
$msg = $error = '';

if ($mid > 0) {
    if (isset($_POST['update_status'])) {
        $request_id = (int)$_POST['request_id'];
        $new_status = trim($_POST['status']);
        
        $valid_statuses = ['accepted', 'in_progress', 'completed'];
        if (in_array($new_status, $valid_statuses)) {
            $conn->query("UPDATE service_requests SET status = '$new_status' WHERE id = $request_id AND mechanic_id = $mid");
            $msg = 'Job status updated to ' . ucfirst(str_replace('_', ' ', $new_status));
        }
    }

    // Fetch jobs that the mechanic is currently handling or has accepted
    $jobs = $conn->query("SELECT sr.*, p.full_name as driver_name, g.name as garage_name 
                          FROM service_requests sr 
                          JOIN profiles p ON p.user_id = sr.driver_id 
                          JOIN garages g ON g.id = sr.garage_id 
                          WHERE sr.mechanic_id = $mid AND sr.status IN ('accepted', 'in_progress') 
                          ORDER BY sr.created_at DESC")->fetch_all(MYSQLI_ASSOC);
} else {
    $jobs = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Current Job – RoadRescue</title>
  <link rel="stylesheet" href="/roadside_ally_php/assets/css/mechanic.css">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>
<div class="main-content">
  <header class="topbar">
    <button class="sidebar-toggle" onclick="toggleSidebar()">&#9776;</button>
    <h2>Mechanic Panel</h2>
  </header>
  <main class="page-body">
    <h1 class="page-title">Current Job Tracking</h1>
    
    <?php if ($msg): ?><div class="alert alert-success"><?= $msg ?></div><?php endif; ?>
    
    <?php if (empty($jobs)): ?>
      <div class="card">
        <div class="card-body text-center text-muted" style="padding:2rem;">You do not have any jobs currently in progress.</div>
      </div>
    <?php else: foreach ($jobs as $j): ?>
      <div class="card" style="margin-bottom:1.25rem;">
        <div class="card-body">
          <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:1rem;">
            <div>
              <p><strong>Garage:</strong> <?= htmlspecialchars($j['garage_name']) ?></p>
              <p><strong>Driver:</strong> <?= htmlspecialchars($j['driver_name']) ?></p>
              <p style="font-size:0.875rem; color:var(--text-muted)">📍 Location: <?= htmlspecialchars($j['location']) ?></p>
              <p style="font-size:0.875rem; color:var(--text-muted)">Service: <?= ucfirst(str_replace('_', ' ', $j['service_type'])) ?></p>
            </div>
            
            <div>
              <form method="POST" style="display:flex; align-items:center; gap:0.5rem;">
                <input type="hidden" name="request_id" value="<?= $j['id'] ?>">
                <select name="status" class="filter-select" required>
                  <option value="accepted" <?= $j['status'] == 'accepted' ? 'selected' : '' ?>>Accepted</option>
                  <option value="in_progress" <?= $j['status'] == 'in_progress' ? 'selected' : '' ?>>In Progress</option>
                  <option value="completed" <?= $j['status'] == 'completed' ? 'selected' : '' ?>>Completed</option>
                </select>
                <button type="submit" name="update_status" class="btn btn-primary btn-sm">Update</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    <?php endforeach; endif; ?>
  </main>
</div>
<script src="/roadside_ally_php/assets/js/main.js"></script>
</body>
</html>