<?php
require_once '../config.php';
requireRole('mechanic');
$uid = $_SESSION['user_id'];

// Get or initialize mechanic record
$mech_row = $conn->query("SELECT * FROM mechanics WHERE user_id = $uid LIMIT 1")->fetch_assoc();
$msg = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $garage_id = !empty($_POST['garage_id']) ? (int)$_POST['garage_id'] : null;
    $is_available = isset($_POST['is_available']) ? 1 : 0;
    
    if ($mech_row) {
        $mid = $mech_row['id'];
        $stmt = $conn->prepare("UPDATE mechanics SET garage_id = ?, is_available = ? WHERE id = ?");
        $stmt->bind_param("iii", $garage_id, $is_available, $mid);
        $stmt->execute() ? $msg = 'Profile updated successfully.' : $error = 'Failed to update profile.';
    } else {
        $stmt = $conn->prepare("INSERT INTO mechanics (user_id, garage_id, is_available) VALUES (?, ?, ?)");
        $stmt->bind_param("iii", $uid, $garage_id, $is_available);
        $stmt->execute() ? $msg = 'Profile created successfully.' : $error = 'Failed to create profile.';
    }
    
    // Refresh the mechanic data
    $mech_row = $conn->query("SELECT * FROM mechanics WHERE user_id = $uid LIMIT 1")->fetch_assoc();
}

// Fetch available garages for selection
$garages = $conn->query("SELECT id, name FROM garages WHERE is_approved = 1")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mechanic Profile – RoadRescue</title>
  <link rel="stylesheet" href="/roadside_ally_php/assets/css/mechanic.css">
  <style>
    .checkbox-container {
      display: flex;
      align-items: center;
      justify-content: flex-start;
      gap: 0.75rem;
      margin: 1.5rem 0;
      text-align: left;
    }
    
    /* Ensure the checkbox control is naturally left aligned without stretching */
    .checkbox-container input[type="checkbox"] {
      width: auto;
      margin: 0;
      cursor: pointer;
    }
  </style>
</head>
<body>
<?php include '../includes/sidebar.php'; ?>

<div class="main-content">
  <header class="topbar">
    <button class="sidebar-toggle" onclick="toggleSidebar()">&#9776;</button>
    <h2>Mechanic Panel</h2>
  </header>
  
  <main class="page-body">
    <h1 class="page-title">Mechanic Profile</h1>
    
    <?php if ($msg): ?>
      <div class="alert alert-success"><?= $msg ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
      <div class="alert alert-error"><?= $error ?></div>
    <?php endif; ?>
    
    <div class="card" style="max-width: 600px;">
      <div class="card-header">
        <strong>Join a Garage & Set Availability</strong>
      </div>
      <div class="card-body">
        <form method="POST">
          
          <div class="form-group">
            <label for="garage_id">Select Garage to Join</label>
            <select name="garage_id" id="garage_id" class="form-control">
              <option value="">Not joined to any garage</option>
              <?php foreach ($garages as $g): ?>
                <option value="<?= $g['id'] ?>" <?= isset($mech_row['garage_id']) && $mech_row['garage_id'] == $g['id'] ? 'selected' : '' ?>>
                  <?= htmlspecialchars($g['name']) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="checkbox-container">
            <input type="checkbox" name="is_available" id="is_available" value="1" <?= isset($mech_row['is_available']) && $mech_row['is_available'] == 1 ? 'checked' : '' ?>>
            <label for="is_available" style="margin-bottom: 0; font-weight: 600; cursor: pointer;">
              I am available for new jobs
            </label>
          </div>

          <button type="submit" class="btn btn-primary btn-full">Save Profile Changes</button>
        </form>
      </div>
    </div>
  </main>
</div>

<script src="/roadside_ally_php/assets/js/main.js"></script>
</body>
</html>